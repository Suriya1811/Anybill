const mongoose = require('mongoose');
const { Schema } = mongoose;

const Startup2Schema = new Schema({
    describeProduct: {
        type: String,
        required: true,
        maxlength: [1000, 'Maximum length is 1000 characters'], 
        trim: true,
    },
    
    describePreviousFundingRound: {
        type: String,
        required: true,
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },

    describeFraction: {
        type: String,
        required: true,
        maxlength: [1000, 'Maximum length is 1000 characters'], 
        trim: true,
    },

    whyCommunityRound: {
        type: String,
        required: true,
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },

    whyVentureLoop: {
        type: String,
        required: true,
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    
    existingCommitments: {
        type: String,
        required: true,
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },

    interestedInPrivateRound: {
        type: Boolean,
        required: true,
    },
}, {
    timestamps: true,
});

module.exports = mongoose.model('Startup2', Startup2Schema);