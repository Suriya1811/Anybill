const mongoose = require('mongoose');
const { Schema } = mongoose;

const ContactandEmailSchema = new Schema({
    contact: {
        type: String,
        match: [/^\d{10}$/, 'Please enter a valid 10-digit phone number'], 
        trim: true, 
    },
    email: {
        type: String,
        match: [/^\S+@\S+\.\S+$/, 'Please enter a valid email address'],
        trim: true,
    },
}, {
    timestamps: true, 
});

userSchema.pre('save', function (next) {
    if ((!this.contact && !this.email) || (this.contact && this.email)) {
        next(new Error('You must provide either a contact or an email, but not both.'));
    } else {
        next();
    }
});

module.exports = mongoose.model('ContactandEmails', ContactandEmailSchema);