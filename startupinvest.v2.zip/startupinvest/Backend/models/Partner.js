const mongoose = require('mongoose');
const { Schema } = mongoose;

const PartnerSchema = new Schema({
    name: {
        type: String,
        required: true, 
        trim: true, 
    },

    occupation: {
        type: String,
        required: true,
    },

    email: {
        type: String,
        required: true,
        unique: true,
        match: [/^\S+@\S+\.\S+$/, 'Please enter a valid email address'], 
    },

    phone: {
        type: String,
        required: true,
        match: [/^\d{10}$/, 'Please enter a valid 10-digit phone number'], 
    },

    authorization: {
        type: Boolean,
        default: false, 
    },

}, {
    timestamps: true,
});

module.exports = mongoose.model('Partner', PartnerSchema);

