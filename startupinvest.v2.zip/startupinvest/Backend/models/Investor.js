const mongoose = require('mongoose');
const { Schema } = mongoose;

const InvestorSchema = new Schema({
    number: {
        type: String,

        match: [/^\d{10}$/, 'Please enter a valid 10-digit phone number'], 
    },

    email: {
        type: String,
       
        unique: true, 
        match: [/^\S+@\S+\.\S+$/, 'Please enter a valid email address'], 
    },

    password: {
        type: String,
        
        minlength: [6, 'Password must be at least 6 characters long'],
    },

    firstName: {
        type: String,
        
        trim: true,
    },

    lastName: {
        type: String,
        
        trim: true,
    },

    gender: {
        type: String,
        enum: ['Male', 'Female', 'Other'],
        
    },

    dob: {
        type: String,
        
    },

    occupation: {
        type: String,
        
    },

    maritalStatus: {
        type: String,
        enum: ['Single', 'Married', 'Divorced', 'Widowed'],
        
    },

    annualGrossIncome: {
        type: String,
        enum: [
            'Below 1LAC', 
            '1-5 LAC', 
            '5-10 LAC', 
            '10-25 LAC', 
            '25LAC-1Cr', 
            '+1Cr'
        ],
        required: [true, 'Annual gross income is required'],
    },

    currentResidentialStatus: {
        type: String,
        
        enum: ['indian', 'nri', 'pio'], 
    },

    addressLine1: {
        type: String,
        
        trim: true,
    },

    addressLine2: {
        type: String,
        trim: true,
    },

    city: {
        type: String,
        
    },

    pincode: {
        type: String,
        
    },

    relativesPoliticallyExposed: {
        type: Boolean,
        
    },

    fatherFirstName: {
        type: String,
        
        trim: true,
    },

    fatherLastName: {
        type: String,
        
        trim: true,
    },

    nomineeName: {
        type: String,
        
        trim: true,
    },

    nomineeDob: {
        type: String,
        
    },

    relationWithNominee: {
        type: String,
        
    },

    // isEighteenOrOlder: {
    //     type: Boolean,
         
    //     validate: {
    //         validator: function () {
    //             return this.isEighteenOrOlder === true; 
    //         },
    //         message: 'You must confirm that you are 18 years or older.',
    //     },
    // },

    // iAccept: {
    //     type: Boolean,
        
    //     validate: {
    //         validator: function () {
    //             return this.iAccept === true; 
    //         },
    //         message: 'You must accept the terms and conditions.',
    //     },
    // },

    panCardNumber: {
        type: String,
        
        match: [/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/, 'Please enter a valid PAN card number'], 
    },

    aadharCardNumber: {
        type: String,
        
        match: [/^\d{12}$/, 'Please enter a valid 12-digit Aadhar number'],
    },

    authorizePAN: {
        type: Boolean,
        
    },

    authorizeAadhar: {
        type: Boolean,
        
    },

    accountType: {
        type: String,
        enum: ['Savings', 'Current', 'Other'], 
        
    },

    ifscCode: {
        type: String,
        
        match: [/^[A-Z]{4}0[A-Z0-9]{6}$/, 'Please enter a valid IFSC code'],
    },
    
    accountNumber: {
        type: String,
        
        match: [/^\d{9,18}$/, 'Please enter a valid account number'],
    },

    accountHolderName: {
        type: String,
    },
    
    yourName: {
        type: String,
    },

    proffessionalBackground: {
        type: String,
    },

    whichFirmDoYouRepresent: {
        type: String,
    },

    experience: {
        type: String,
    },

    investAsIndividualOrAsFirm: {
        type: String,
    },

    industriesOfInterest: {
        type: String,
    },

    stageOfStartupsYouInvest: {
        type: String,
    },

    georaphicalRegionsYouFocusForInvest: {
        type: String,
    },

    B2BorB2C: {
        type: String,
    },

    specificTypeOfFounders: {
        type: String,
    },

    investmentrange: {
        type: String,
    },

    doYouOfferFollowonFunding: {
        type: String,
    },

    whatPercentageOfEquityDoYouAim: {
        type: String,
    },

    aeYouOpenToConevrtibleNotesOrSAFEs: {
        type: String,
    },
}, {
    timestamps: true,
});

module.exports = mongoose.model('Investor', InvestorSchema);