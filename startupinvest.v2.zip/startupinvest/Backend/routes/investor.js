const express = require('express');
const router = express.Router();
const Investor = require('../models/Investor');
const fetchinvestor = require('../middleware/fetchinvestor');
const { check, validationResult } = require('express-validator');
const bcrypt = require('bcryptjs');
var jwt = require('jsonwebtoken');
const JWT_SECRET = 'Yuf%@VC67V%^&EV^%672bvbv6e2'

//Route:1 , Create a Investor using POST '/api/investor/'
  router.post('/',
    [
      // Validation using express-validator
      check('number')
        .matches(/^\d{10}$/)
        .withMessage('Please enter a valid 10-digit phone number'),
      check('email')
        .isEmail()
        .withMessage('Please enter a valid email address'),
      check('password')
        .isLength({ min: 6 })
        .withMessage('Password must be at least 6 characters long'),
      check('gender')
        .isIn(['Male', 'Female', 'Other'])
        .withMessage('Gender must be Male, Female, or Other'),
      check('maritalStatus')
        .isIn(['Single', 'Married', 'Divorced', 'Widowed'])
        .withMessage('Marital status must be Single, Married, Divorced, or Widowed'),
      check('currentResidentialStatus')
        .isIn(['indian', 'nri', 'pio'])
        .withMessage('Residential status must be indian, nri, pio'),
      check('panCardNumber')
        .matches(/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/)
        .withMessage('Please enter a valid PAN card number'),
      check('aadharCardNumber')
        .matches(/^\d{12}$/)
        .withMessage('Please enter a valid 12-digit Aadhar number'),
      check('ifscCode')
        .matches(/^[A-Z]{4}0[A-Z0-9]{6}$/)
        .withMessage('Please enter a valid IFSC code'),
      check('accountNumber')
        .matches(/^\d{9,18}$/)
        .withMessage('Please enter a valid account number'),
      check('iAccept')
        .equals('true')
        .withMessage('You must accept the terms and conditions'),
      check('isEighteenOrOlder')
        .equals('true')
        .withMessage('You must confirm that you are 18 years or older'),
    ],
    async (req, res) => {
      // Check for validation errors
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }
  
      try {
        // Check if email or phone number already exists
        const existingInvestor = await Investor.findOne({
          $or: [{ email: req.body.email }, { number: req.body.number }],
        });
        if (existingInvestor) {
          return res.status(400).json({
            error: 'An investor with this email or phone number already exists',
          });
        }
  
        // Hash the password before saving it
        const salt = await bcrypt.genSalt(10); // Generate salt
        const hashedPassword = await bcrypt.hash(req.body.password, salt); // Hash password
  
        // Create a new investor object with the hashed password
        const investor = new Investor({
          ...req.body,
          password: hashedPassword, // Save the hashed password
        });
  
        // Save the investor
        await investor.save();

        const data = {
            investor: {
                id: investor.id
            }
        }

        const authtoken = jwt.sign(data, JWT_SECRET);
        console.log(authtoken);
  
        res.status(201).json({authtoken});
      } catch (err) {
        console.error(err.message);
        res.status(500).json({ message: 'Server error' });
      }
    }
  );


//Route:2 , Login a Investor using POST '/api/investor/login'
  router.post('/login',
    [
      // Validation using express-validator
      check('email')
        .isEmail()
        .withMessage('Please enter a valid email address'),
      check('password')
        .exists()
        .withMessage('Password must be at least 6 characters long'),
    ],
    async (req, res) => {
      // Check for validation errors
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }
  
      const { email, password } = req.body;
  
      try {
        // Check if email or phone number already exists
        let existingInvestor = await Investor.findOne({ email });
        if (!existingInvestor) {
          return res.status(400).json({ error: 'Sorry, wrong credentials' });
        }
  
        // Compare the password (async method)
        const passwordCompare = await bcrypt.compare(password, existingInvestor.password);
        if (!passwordCompare) {
          return res.status(400).json({ error: 'Sorry, wrong credentials' });
        }
  
        const data = {
          investor: {
            id: existingInvestor.id,
          },
        };
  
        const authtoken = jwt.sign(data, JWT_SECRET);
        console.log(authtoken);
  
        res.status(201).json({ authtoken });
      } catch (err) {
        console.error(err.message);
        res.status(500).json({ message: 'Server error' });
      }
    }
  );


//Route:3 , Get Investor data based on email using POST '/api/investor/fetchinvestor' (Login Required)
router.post('/getinvestor', fetchinvestor, async (req, res) => {
  
    try {
      investorid = req.investor.id;
      const investor = await Investor.findById(investorid).select('-password')
      res.send(investor)
    } catch (err) {
      console.error(err.message);
      res.status(500).json({ message: 'Server error' });
    }
  }
);


//Route:4 , Update Investor data based on Id using PUT '/api/investor/update/:id' (Login Required)
// router.put('/update/:id', async (req, res) => {
//   const {
//     number,
//     email,
//     password,
//     firstName,
//     lastName,
//     gender,
//     dob,
//     occupation,
//     maritalStatus,
//     annualGrossIncome,
//     currentResidentialStatus,
//     addressLine1,
//     addressLine2,
//     city,
//     pincode,
//     relativesPoliticallyExposed,
//     fatherFirstName,
//     fatherLastName,
//     nomineeName,
//     nomineeDob,
//     relationWithNominee,
//     isEighteenOrOlder,
//     iAccept,
//     panCardNumber,
//     aadharCardNumber,
//     authorizePAN,
//     authorizeAadhar,
//     accountType,
//     accountHolderName,
//     ifscCode,
//     accountNumber,
//   } = req.body;

//   const newInvestor = {};
//   if (number) { newInvestor.number = number };
//   if (email) { newInvestor.email = email };
//   if (password) { newInvestor.password = password };
//   if (firstName) { newInvestor.firstName = firstName };
//   if (lastName) { newInvestor.lastName = lastName };
//   if (gender) { newInvestor.gender = gender };
//   if (dob) { newInvestor.dob = dob };
//   if (occupation) { newInvestor.occupation = occupation };
//   if (maritalStatus) { newInvestor.maritalStatus = maritalStatus };
//   if (annualGrossIncome) { newInvestor.annualGrossIncome = annualGrossIncome };
//   if (currentResidentialStatus) { newInvestor.currentResidentialStatus = currentResidentialStatus };
//   if (addressLine1) { newInvestor.addressLine1 = addressLine1 };
//   if (addressLine2) { newInvestor.addressLine2 = addressLine2 };
//   if (city) { newInvestor.city = city };
//   if (pincode) { newInvestor.pincode = pincode };
//   if (relativesPoliticallyExposed) { newInvestor.relativesPoliticallyExposed = relativesPoliticallyExposed };
//   if (fatherFirstName) { newInvestor.fatherFirstName = fatherFirstName };
//   if (fatherLastName) { newInvestor.fatherLastName = fatherLastName };
//   if (nomineeName) { newInvestor.nomineeName = nomineeName };
//   if (nomineeDob) { newInvestor.nomineeDob = nomineeDob };
//   if (relationWithNominee) { newInvestor.relationWithNominee = relationWithNominee };
//   if (isEighteenOrOlder) { newInvestor.isEighteenOrOlder = isEighteenOrOlder };
//   if (iAccept) { newInvestor.iAccept = iAccept };
//   if (panCardNumber) { newInvestor.panCardNumber = panCardNumber };
//   if (aadharCardNumber) { newInvestor.aadharCardNumber = aadharCardNumber };
//   if (authorizePAN) { newInvestor.authorizePAN = authorizePAN };
//   if (authorizeAadhar) { newInvestor.authorizeAadhar = authorizeAadhar };
//   if (accountType) { newInvestor.accountType = accountType };
//   if (accountHolderName) { newInvestor.accountHolderName = accountHolderName };
//   if (ifscCode) { newInvestor.ifscCode = ifscCode };
//   if (accountNumber) { newInvestor.accountNumber = accountNumber };

//   try {
//     let investor = await Investor.findById(req.params.id);
//     if (!investor) {
//       return res.status(404).json({ error: 'Investor not found' });
//     }

//     // Check if email or number already exists before updating
//     if (newInvestor.email) {
//       const existingEmail = await Investor.findOne({ email: newInvestor.email });
//       if (existingEmail && existingEmail._id.toString() !== req.params.id) {
//         return res.status(400).json({ error: 'Email already exists' });
//       }
//     }

//     if (newInvestor.number) {
//       const existingNumber = await Investor.findOne({ number: newInvestor.number });
//       if (existingNumber && existingNumber._id.toString() !== req.params.id) {
//         return res.status(400).json({ error: 'Number already exists' });
//       }
//     }

//     // Update the investor data
//     investor = await Investor.findByIdAndUpdate(req.params.id, { $set: newInvestor }, { new: true });
//     res.json(investor);
//   } catch (err) {
//     console.error(err.message);
//     res.status(500).json({ error: 'Server Error' });
//   }
// });

router.put('/update/:id', async (req, res) => {
  const {
    number,
    email,
    password,
    firstName,
    lastName,
    gender,
    dob,
    occupation,
    maritalStatus,
    annualGrossIncome,
    currentResidentialStatus,
    addressLine1,
    addressLine2,
    city,
    pincode,
    relativesPoliticallyExposed,
    fatherFirstName,
    fatherLastName,
    nomineeName,
    nomineeDob,
    relationWithNominee,
    // isEighteenOrOlder,
    // iAccept,
    panCardNumber,
    aadharCardNumber,
    authorizePAN,
    authorizeAadhar,
    accountType,
    accountHolderName,
    ifscCode,
    accountNumber,
    yourName,
    proffessionalBackground,
    whichFirmDoYouRepresent,
    experience,
    investAsIndividualOrAsFirm,
    industriesOfInterest,
    stageOfStartupsYouInvest,
    georaphicalRegionsYouFocusForInvest,
    B2BorB2C,
    specificTypeOfFounders,
    investmentrange,
    doYouOfferFollowonFunding,
    whatPercentageOfEquityDoYouAim,
    aeYouOpenToConevrtibleNotesOrSAFEs,
  } = req.body;

  const newInvestor = {};
  if (number) newInvestor.number = number;
  if (email) newInvestor.email = email;
  if (password) newInvestor.password = password;
  if (firstName) newInvestor.firstName = firstName;
  if (lastName) newInvestor.lastName = lastName;
  if (gender) newInvestor.gender = gender;
  if (dob) newInvestor.dob = dob;
  if (occupation) newInvestor.occupation = occupation;
  if (maritalStatus) newInvestor.maritalStatus = maritalStatus;
  if (annualGrossIncome) newInvestor.annualGrossIncome = annualGrossIncome;
  if (currentResidentialStatus) newInvestor.currentResidentialStatus = currentResidentialStatus;
  if (addressLine1) newInvestor.addressLine1 = addressLine1;
  if (addressLine2) newInvestor.addressLine2 = addressLine2;
  if (city) newInvestor.city = city;
  if (pincode) newInvestor.pincode = pincode;
  if (relativesPoliticallyExposed !== undefined) newInvestor.relativesPoliticallyExposed = relativesPoliticallyExposed;
  if (fatherFirstName) newInvestor.fatherFirstName = fatherFirstName;
  if (fatherLastName) newInvestor.fatherLastName = fatherLastName;
  if (nomineeName) newInvestor.nomineeName = nomineeName;
  if (nomineeDob) newInvestor.nomineeDob = nomineeDob;
  if (relationWithNominee) newInvestor.relationWithNominee = relationWithNominee;
  // if (isEighteenOrOlder !== undefined) newInvestor.isEighteenOrOlder = isEighteenOrOlder;
  // if (iAccept !== undefined) newInvestor.iAccept = iAccept;
  if (panCardNumber) newInvestor.panCardNumber = panCardNumber;
  if (aadharCardNumber) newInvestor.aadharCardNumber = aadharCardNumber;
  if (authorizePAN !== undefined) newInvestor.authorizePAN = authorizePAN;
  if (authorizeAadhar !== undefined) newInvestor.authorizeAadhar = authorizeAadhar;
  if (accountType) newInvestor.accountType = accountType;
  if (accountHolderName) newInvestor.accountHolderName = accountHolderName;
  if (ifscCode) newInvestor.ifscCode = ifscCode;
  if (accountNumber) newInvestor.accountNumber = accountNumber;
  if (yourName) newInvestor.yourName = yourName;
  if (proffessionalBackground) newInvestor.proffessionalBackground = proffessionalBackground;
  if (whichFirmDoYouRepresent) newInvestor.whichFirmDoYouRepresent = whichFirmDoYouRepresent;
  if (experience) newInvestor.experience = experience;
  if (investAsIndividualOrAsFirm) newInvestor.investAsIndividualOrAsFirm = investAsIndividualOrAsFirm;
  if (industriesOfInterest) newInvestor.industriesOfInterest = industriesOfInterest;
  if (stageOfStartupsYouInvest) newInvestor.stageOfStartupsYouInvest = stageOfStartupsYouInvest;
  if (georaphicalRegionsYouFocusForInvest) newInvestor.georaphicalRegionsYouFocusForInvest = georaphicalRegionsYouFocusForInvest;
  if (B2BorB2C) newInvestor.B2BorB2C = B2BorB2C;
  if (specificTypeOfFounders) newInvestor.specificTypeOfFounders = specificTypeOfFounders;
  if (investmentrange) newInvestor.investmentrange = investmentrange;
  if (doYouOfferFollowonFunding) newInvestor.doYouOfferFollowonFunding = doYouOfferFollowonFunding;
  if (whatPercentageOfEquityDoYouAim) newInvestor.whatPercentageOfEquityDoYouAim = whatPercentageOfEquityDoYouAim;
  if (aeYouOpenToConevrtibleNotesOrSAFEs) newInvestor.aeYouOpenToConevrtibleNotesOrSAFEs = aeYouOpenToConevrtibleNotesOrSAFEs;

  try {
    let investor = await Investor.findById(req.params.id);
    if (!investor) {
      return res.status(404).json({ error: 'Investor not found' });
    }

    // Check for unique constraints
    if (newInvestor.email) {
      const existingEmail = await Investor.findOne({ email: newInvestor.email });
      if (existingEmail && existingEmail._id.toString() !== req.params.id) {
        return res.status(400).json({ error: 'Email already exists' });
      }
    }

    if (newInvestor.number) {
      const existingNumber = await Investor.findOne({ number: newInvestor.number });
      if (existingNumber && existingNumber._id.toString() !== req.params.id) {
        return res.status(400).json({ error: 'Number already exists' });
      }
    }

    // Update the investor data
    investor = await Investor.findByIdAndUpdate(req.params.id, { $set: newInvestor }, { new: true });
    res.json(investor);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ error: 'Server Error' });
  }
});


router.put('/updatehome/:id', async (req, res) => {
  const {
    number,
    email,
    password,
    firstName,
    lastName,
    gender,
    dob,
    occupation,
    maritalStatus,
    annualGrossIncome,
    currentResidentialStatus,
    addressLine1,
    addressLine2,
    city,
    pincode,
    relativesPoliticallyExposed,
    fatherFirstName,
    fatherLastName,
    nomineeName,
    nomineeDob,
    relationWithNominee,
    isEighteenOrOlder,
    iAccept,
    panCardNumber,
    aadharCardNumber,
    authorizePAN,
    authorizeAadhar,
    accountType,
    accountHolderName,
    ifscCode,
    accountNumber,
    yourName,
    proffessionalBackground,
    whichFirmDoYouRepresent,
    experience,
    investAsIndividualOrAsFirm,
    industriesOfInterest,
    stageOfStartupsYouInvest,
    georaphicalRegionsYouFocusForInvest,
    B2BorB2C,
    specificTypeOfFounders,
    investmentrange,
    doYouOfferFollowonFunding,
    whatPercentageOfEquityDoYouAim,
    aeYouOpenToConevrtibleNotesOrSAFEs,
  } = req.body;

  const newInvestor = {};
  if (number) newInvestor.number = number;
  if (email) newInvestor.email = email;
  if (password) newInvestor.password = password;
  if (firstName) newInvestor.firstName = firstName;
  if (lastName) newInvestor.lastName = lastName;
  if (gender) newInvestor.gender = gender;
  if (dob) newInvestor.dob = dob;
  if (occupation) newInvestor.occupation = occupation;
  if (maritalStatus) newInvestor.maritalStatus = maritalStatus;
  if (annualGrossIncome) newInvestor.annualGrossIncome = annualGrossIncome;
  if (currentResidentialStatus) newInvestor.currentResidentialStatus = currentResidentialStatus;
  if (addressLine1) newInvestor.addressLine1 = addressLine1;
  if (addressLine2) newInvestor.addressLine2 = addressLine2;
  if (city) newInvestor.city = city;
  if (pincode) newInvestor.pincode = pincode;
  if (relativesPoliticallyExposed !== undefined) newInvestor.relativesPoliticallyExposed = relativesPoliticallyExposed;
  if (fatherFirstName) newInvestor.fatherFirstName = fatherFirstName;
  if (fatherLastName) newInvestor.fatherLastName = fatherLastName;
  if (nomineeName) newInvestor.nomineeName = nomineeName;
  if (nomineeDob) newInvestor.nomineeDob = nomineeDob;
  if (relationWithNominee) newInvestor.relationWithNominee = relationWithNominee;
  if (isEighteenOrOlder !== undefined) newInvestor.isEighteenOrOlder = isEighteenOrOlder;
  if (iAccept !== undefined) newInvestor.iAccept = iAccept;
  if (panCardNumber) newInvestor.panCardNumber = panCardNumber;
  if (aadharCardNumber) newInvestor.aadharCardNumber = aadharCardNumber;
  if (authorizePAN !== undefined) newInvestor.authorizePAN = authorizePAN;
  if (authorizeAadhar !== undefined) newInvestor.authorizeAadhar = authorizeAadhar;
  if (accountType) newInvestor.accountType = accountType;
  if (accountHolderName) newInvestor.accountHolderName = accountHolderName;
  if (ifscCode) newInvestor.ifscCode = ifscCode;
  if (accountNumber) newInvestor.accountNumber = accountNumber;
  if (yourName) newInvestor.yourName = yourName;
  if (proffessionalBackground) newInvestor.proffessionalBackground = proffessionalBackground;
  if (whichFirmDoYouRepresent) newInvestor.whichFirmDoYouRepresent = whichFirmDoYouRepresent;
  if (experience) newInvestor.experience = experience;
  if (investAsIndividualOrAsFirm) newInvestor.investAsIndividualOrAsFirm = investAsIndividualOrAsFirm;
  if (industriesOfInterest) newInvestor.industriesOfInterest = industriesOfInterest;
  if (stageOfStartupsYouInvest) newInvestor.stageOfStartupsYouInvest = stageOfStartupsYouInvest;
  if (georaphicalRegionsYouFocusForInvest) newInvestor.georaphicalRegionsYouFocusForInvest = georaphicalRegionsYouFocusForInvest;
  if (B2BorB2C) newInvestor.B2BorB2C = B2BorB2C;
  if (specificTypeOfFounders) newInvestor.specificTypeOfFounders = specificTypeOfFounders;
  if (investmentrange) newInvestor.investmentrange = investmentrange;
  if (doYouOfferFollowonFunding) newInvestor.doYouOfferFollowonFunding = doYouOfferFollowonFunding;
  if (whatPercentageOfEquityDoYouAim) newInvestor.whatPercentageOfEquityDoYouAim = whatPercentageOfEquityDoYouAim;
  if (aeYouOpenToConevrtibleNotesOrSAFEs) newInvestor.aeYouOpenToConevrtibleNotesOrSAFEs = aeYouOpenToConevrtibleNotesOrSAFEs;

  try {
    let investor = await Investor.findById(req.params.id);
    if (!investor) {
      return res.status(404).json({ error: 'Investor not found' });
    }

    // Update the investor data
    investor = await Investor.findByIdAndUpdate(req.params.id, { $set: newInvestor }, { new: true });
    res.json(investor);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ error: 'Server Error' });
  }
});

// router.put('/updatepassword/:id', async (req, res) => {
//   const { currentPassword, password } = req.body;

//   try {
//     // Fetch the investor by ID
//     let investor = await Investor.findById(req.params.id);
//     if (!investor) {
//       return res.status(404).json({ error: 'Investor not found' });
//     }

//     // Compare the current password with the stored hashed password
//     const isMatch = await bcrypt.compare(currentPassword, investor.password);
//     if (!isMatch) {
//       return res.status(400).json({ error: 'Current password is incorrect' });
//     }

//     // Hash the new password
//     const salt = await bcrypt.genSalt(10);
//     const hashedPassword = await bcrypt.hash(password, salt);

//     // Update the investor's password
//     investor.password = hashedPassword;
//     await investor.save();

//     res.json({ message: 'Password updated successfully' });
//   } catch (err) {
//     console.error(err.message);
//     res.status(500).json({ error: 'Server Error' });
//   }
// });

// router.put('/updatepassword/:id', async (req, res) => {
//   const { currentPassword, password } = req.body;

//   try {
//     // Fetch the investor by ID
//     let investor = await Investor.findById(req.params.id);
//     if (!investor) {
//       return res.status(404).json({ error: 'Investor not found' });
//     }

//     // Compare the current password directly
//     if (investor.password !== currentPassword) {
//       return res.status(400).json({ error: 'Current password is incorrect' });
//     }

//     // Update the investor's password
//     investor.password = password;
//     await investor.save();

//     res.json({ message: 'Password updated successfully' });
//   } catch (err) {
//     console.error(err.message);
//     res.status(500).json({ error: 'Server Error' });
//   }
// });



router.put('/updatepassword/:id', async (req, res) => {
  const { currentPassword, password } = req.body;

  try {
    // Fetch the investor by ID
    let investor = await Investor.findById(req.params.id);
    if (!investor) {
      return res.status(404).json({ error: 'Investor not found' });
    }

    // Compare the current password
    const isMatch = await bcrypt.compare(currentPassword, investor.password);
    if (!isMatch) {
      return res.status(400).json({ error: 'Current password is incorrect' });
    }

    // Hash the new password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Update the investor's password
    investor.password = hashedPassword;
    await investor.save();

    res.json({ message: 'Password updated successfully' });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ error: 'Server Error' });
  }
});




//Route:5 , Get Investor data based on email using GET '/api/investor/getInvestorByEmail/:email' (Login Required)
router.get('/getInvestorByEmail/:email', async (req, res) => {
  try {
      const { email } = req.params; // Extract email from URL parameters

      if (!email) {
          return res.status(400).json({ error: 'Email is required' });
      }

      // Find investor by email
      const investor = await Investor.findOne({ email });

      if (!investor) {
          return res.status(404).json({ error: 'Investor not found' });
      }

      // Return the matched investor data
      res.status(200).json(investor);
  } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Server error' });
  }
});


//Route:6 , Check entered email using GET '/api/investor/check-email/:email' (Login Required)
router.post('/check-email', async (req, res) => {
  const { email, password } = req.body; // Both email and password come in the request body

  try {
    // Find user by email
    const user = await Investor.findOne({ email });

    if (!user) {
      return res.status(404).json({ message: 'Email is not found.' });
    }

    // Compare the password with the hashed password in the database
    const isMatch = await bcrypt.compare(password, user.password);

    if (isMatch) {
      // Send the user's ID in the response
      return res.status(200).json({ message: 'Email and password are correct.', userId: user._id });
    } else {
      return res.status(400).json({ message: 'Invalid password.' });
    }

  } catch (error) {
    return res.status(500).json({ message: 'Server error. Please try again later.' });
  }
});



//Route:7 , Update using email using PUT '/api/investor/updatebyemail/:email' (Login Required)
router.put('/updateByEmail/:email', async (req, res) => {
  const {
    number,
    email,
    password,
    firstName,
    lastName,
    gender,
    dob,
    occupation,
    maritalStatus,
    annualGrossIncome,
    currentResidentialStatus,
    addressLine1,
    addressLine2,
    city,
    pincode,
    relativesPoliticallyExposed,
    fatherFirstName,
    fatherLastName,
    nomineeName,
    nomineeDob,
    relationWithNominee,
    isEighteenOrOlder,
    iAccept,
    panCardNumber,
    aadharCardNumber,
    authorizePAN,
    authorizeAadhar,
    accountType,
    accountHolderName,
    ifscCode,
    accountNumber,
    yourName,
    proffessionalBackground,
    whichFirmDoYouRepresent,
    experience,
    investAsIndividualOrAsFirm,
    industriesOfInterest,
    stageOfStartupsYouInvest,
    georaphicalRegionsYouFocusForInvest,
    B2BorB2C,
    specificTypeOfFounders,
    investmentrange,
    doYouOfferFollowonFunding,
    whatPercentageOfEquityDoYouAim,
    aeYouOpenToConevrtibleNotesOrSAFEs,
  } = req.body;

  const newInvestor = {};
  if (number) newInvestor.number = number;
  if (email) newInvestor.email = email;
  if (password) newInvestor.password = password;
  if (firstName) newInvestor.firstName = firstName;
  if (lastName) newInvestor.lastName = lastName;
  if (gender) newInvestor.gender = gender;
  if (dob) newInvestor.dob = dob;
  if (occupation) newInvestor.occupation = occupation;
  if (maritalStatus) newInvestor.maritalStatus = maritalStatus;
  if (annualGrossIncome) newInvestor.annualGrossIncome = annualGrossIncome;
  if (currentResidentialStatus) newInvestor.currentResidentialStatus = currentResidentialStatus;
  if (addressLine1) newInvestor.addressLine1 = addressLine1;
  if (addressLine2) newInvestor.addressLine2 = addressLine2;
  if (city) newInvestor.city = city;
  if (pincode) newInvestor.pincode = pincode;
  if (relativesPoliticallyExposed !== undefined) newInvestor.relativesPoliticallyExposed = relativesPoliticallyExposed;
  if (fatherFirstName) newInvestor.fatherFirstName = fatherFirstName;
  if (fatherLastName) newInvestor.fatherLastName = fatherLastName;
  if (nomineeName) newInvestor.nomineeName = nomineeName;
  if (nomineeDob) newInvestor.nomineeDob = nomineeDob;
  if (relationWithNominee) newInvestor.relationWithNominee = relationWithNominee;
  if (isEighteenOrOlder !== undefined) newInvestor.isEighteenOrOlder = isEighteenOrOlder;
  if (iAccept !== undefined) newInvestor.iAccept = iAccept;
  if (panCardNumber) newInvestor.panCardNumber = panCardNumber;
  if (aadharCardNumber) newInvestor.aadharCardNumber = aadharCardNumber;
  if (authorizePAN !== undefined) newInvestor.authorizePAN = authorizePAN;
  if (authorizeAadhar !== undefined) newInvestor.authorizeAadhar = authorizeAadhar;
  if (accountType) newInvestor.accountType = accountType;
  if (accountHolderName) newInvestor.accountHolderName = accountHolderName;
  if (ifscCode) newInvestor.ifscCode = ifscCode;
  if (accountNumber) newInvestor.accountNumber = accountNumber;
  if (yourName) newInvestor.yourName = yourName;
  if (proffessionalBackground) newInvestor.proffessionalBackground = proffessionalBackground;
  if (whichFirmDoYouRepresent) newInvestor.whichFirmDoYouRepresent = whichFirmDoYouRepresent;
  if (experience) newInvestor.experience = experience;
  if (investAsIndividualOrAsFirm) newInvestor.investAsIndividualOrAsFirm = investAsIndividualOrAsFirm;
  if (industriesOfInterest) newInvestor.industriesOfInterest = industriesOfInterest;
  if (stageOfStartupsYouInvest) newInvestor.stageOfStartupsYouInvest = stageOfStartupsYouInvest;
  if (georaphicalRegionsYouFocusForInvest) newInvestor.georaphicalRegionsYouFocusForInvest = georaphicalRegionsYouFocusForInvest;
  if (B2BorB2C) newInvestor.B2BorB2C = B2BorB2C;
  if (specificTypeOfFounders) newInvestor.specificTypeOfFounders = specificTypeOfFounders;
  if (investmentrange) newInvestor.investmentrange = investmentrange;
  if (doYouOfferFollowonFunding) newInvestor.doYouOfferFollowonFunding = doYouOfferFollowonFunding;
  if (whatPercentageOfEquityDoYouAim) newInvestor.whatPercentageOfEquityDoYouAim = whatPercentageOfEquityDoYouAim;
  if (aeYouOpenToConevrtibleNotesOrSAFEs) newInvestor.aeYouOpenToConevrtibleNotesOrSAFEs = aeYouOpenToConevrtibleNotesOrSAFEs;

  try {
    // Find investor by email
    let investor = await Investor.findOne({ email: req.params.email });
    if (!investor) {
      return res.status(404).json({ error: 'Investor not found' });
    }

    // Check if number already exists before updating
    if (newInvestor.number) {
      const existingNumber = await Investor.findOne({ number: newInvestor.number });
      if (existingNumber && existingNumber._id.toString() !== investor._id.toString()) {
        return res.status(400).json({ error: 'Number already exists' });
      }
    }

    // Update investor data
    investor = await Investor.findOneAndUpdate(
      { email: req.params.email },
      { $set: newInvestor },
      { new: true }
    );
    res.json(investor);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ error: 'Server Error' });
  }
});


//Route:8 , Get investor using GET '/api/investor/getInvestorById/:id' (Login Required)
router.get('/getInvestorById/:id', async (req, res) => {
  try {
      const { id } = req.params; // Extract id from URL parameters

      if (!id) {
          return res.status(400).json({ error: 'ID is required' });
      }

      // Find investor by id
      const investor = await Investor.findById(id);

      if (!investor) {
          return res.status(404).json({ error: 'Investor not found' });
      }

      // Return the matched investor data
      res.status(200).json(investor);
  } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Server error' });
  }
});


router.get('/getAllInvestors', async (req, res) => {
  try {
      // Fetch all investors from the database
      const investors = await Investor.find();

      if (!investors || investors.length === 0) {
          return res.status(404).json({ error: 'No investors found' });
      }

      // Return the list of all investors
      res.status(200).json(investors);
  } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Server error' });
  }
});


router.get('/investors', async (req, res) => {
  try {
      const investors = await Investor.find().sort({ createdAt: -1 });
      res.status(200).json(investors);
  } catch (error) {
      res.status(500).json({ message: 'Error fetching investors', error });
  }
});


  module.exports = router;