const express = require('express');
const router = express.Router();
const Startup = require('../models/Startup');

// Fetch all startups
router.get('/startups', async (req, res) => {
    try {
        const startups = await Startup.find().sort({ createdAt: -1 });
        res.status(200).json(startups);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching startups', error });
    }
});

// Fetch startup by ID
router.get('/startups/:id', async (req, res) => {
    try {
        const startup = await Startup.findById(req.params.id);
        if (!startup) {
            return res.status(404).json({ message: 'Startup not found' });
        }
        res.status(200).json(startup);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching startup', error });
    }
});

// ✅ New: Fetch startups with similar email (case-insensitive)
router.get('/startups/email/search', async (req, res) => {
    const { email } = req.query;

    if (!email) {
        return res.status(400).json({ message: 'Email query parameter is required' });
    }

    try {
        const startups = await Startup.find({
            email: { $regex: email, $options: 'i' } // 'i' for case-insensitive
        });

        res.status(200).json(startups);
    } catch (error) {
        res.status(500).json({ message: 'Error searching startups by email', error });
    }
});
module.exports = router;
