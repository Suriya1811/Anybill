const express = require('express');
const router = express.Router();
const Partner = require('../models/Partner');
const { check, validationResult } = require('express-validator');
var jwt = require('jsonwebtoken');


// router.post('/', (req, res) => {
//     console.log(req.body);
//     const data = req.body
//     const partner = Partner(req.body);
//     partner.save();
//     res.json(data);
// });


router.post(
    '/',
    [
      // Validation rules
      check('name').trim().notEmpty().withMessage('Name is required'),
      check('occupation').notEmpty().withMessage('Occupation is required'),
      check('email')
        .isEmail()
        .withMessage('Please enter a valid email address'),
      check('phone')
        .matches(/^\d{10}$/)
        .withMessage('Please enter a valid 10-digit phone number'),
      check('authorization')
        .optional()
        .isBoolean()
        .withMessage('Authorization must be a boolean value'),
    ],
    async (req, res) => {
      // Check for validation errors
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }
  
      try {
        // Save to the database if validation passes
        let partner = await Partner.findOne({ email: req.body.email }); // Await the result of findOne
        if (partner) {
          return res.status(400).json({ error: "OOPS, A user with this email already exists" });
        }
      
        partner = new Partner(req.body); // Create a new Partner if no user exists
        await partner.save(); // Save the new Partner
        res.status(201).json({ message: "Partner added successfully", data: partner });
      } catch (err) {
        console.error(err.message);
        res.status(500).json({ message: "Server error" });
      }
    }
  );


  module.exports = router;