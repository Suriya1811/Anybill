import React, { useState, useEffect } from 'react';

const host = "http://localhost:5000";

const UploadsDownloadPage = () => {
  const [pdfs, setPdfs] = useState([]);

  const fetchAllPdfs = async () => {
    try {
      const response = await fetch(`${host}/api/startup/listPdfs`);
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || 'Failed to fetch PDFs');
      }
      const fetchedPdfs = data.pdfs.map(pdf => ({
        fileName: pdf.fileName,
        blob: base64ToBlob(pdf.content, 'application/pdf'),
      }));
      setPdfs(fetchedPdfs);
    } catch (error) {
      console.error('Error fetching PDFs:', error.message);
    }
  };

  const base64ToBlob = (base64, mimeType) => {
    const byteCharacters = atob(base64);
    const byteArrays = [];
    for (let offset = 0; offset < byteCharacters.length; offset += 512) {
      const slice = byteCharacters.slice(offset, offset + 512);
      const byteNumbers = new Array(slice.length);
      for (let i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      byteArrays.push(byteArray);
    }
    return new Blob(byteArrays, { type: mimeType });
  };

  const downloadAllPdfs = () => {
    if (pdfs.length === 0) {
      alert('No PDFs available for download.');
      return;
    }
    pdfs.forEach(pdf => {
      const link = document.createElement('a');
      const url = URL.createObjectURL(pdf.blob);
      link.href = url;
      link.download = pdf.fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    });
  };

  useEffect(() => {
    fetchAllPdfs();
  }, []);

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-3xl font-bold text-center mb-6">Uploads PDFs</h1>
      <div className="flex justify-center mb-6">
        <button
          onClick={downloadAllPdfs}
          className="bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded"
        >
          Download All PDFs
        </button>
      </div>
      <ul className="max-w-lg mx-auto space-y-4">
        {pdfs.map((pdf, index) => (
          <li key={index} className="flex items-center justify-between bg-gray-100 p-4 rounded shadow">
            <span className="text-base font-medium">{pdf.fileName}</span>
            <button
              onClick={() => {
                const link = document.createElement('a');
                const url = URL.createObjectURL(pdf.blob);
                link.href = url;
                link.download = pdf.fileName;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                URL.revokeObjectURL(url);
              }}
              className="bg-green-500 hover:bg-green-600 text-white py-1 px-3 rounded text-sm"
            >
              Download
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default UploadsDownloadPage;
