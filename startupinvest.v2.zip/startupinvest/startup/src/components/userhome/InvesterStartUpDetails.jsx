import React, { useState, useEffect } from 'react';
import UserNavbar from '../userhome/UserNavbar'

const InvesterStartUpDetails = () => {
    const host = "http://localhost:5000";
    const [activeButton, setActiveButton] = useState('News & articles');
    const [currentPage, setCurrentPage] = useState(1);
    const [fetchedData, setFetchedData] = useState([]);

    useEffect(() => {
        const controller = new AbortController();
        const signal = controller.signal;
    
        const fetchData = async () => {
          try {
            const response = await fetch(`${host}/test1/startups`, {
              method: 'GET',
              headers: {
                'Content-Type': 'application/json',
              },
              signal,
            });
    
            if (!response.ok) throw new Error("Network response was not ok");
    
            const data = await response.json();
            console.log(data);
            setFetchedData(data);
          } catch (error) {
            if (error.name === 'AbortError') {
              console.log('Fetch aborted');
            } else {
              console.error('Fetch error:', error);
            }
          }
        };
    
        fetchData();
    
        // Cleanup function to abort fetch
        return () => {
          controller.abort();
        };
      }, []);

  return (
    <>
    <UserNavbar/>

    <div className='relative'>
            <div className='md:absolute md:top-0 md:right-0 md:pl-[306px] w-full'>
                {/* <div className='incompleteKYC py-[20px] pl-[42px] pr-[40px] flex items-center justify-between flex-wrap bg-[#f7d8d7]'>
                        <p className='text-[16px] font-[400] text-[#222] flex'>
                            <img alt="alertred2" loading="lazy" width="24" height="25" decoding="async" data-nimg="1" className="mr-[8px]" src="https://investor.creddinv.in/_next/static/media/alertred2.1cebdb24.svg"/>
                            <span className='font-[500]'>KYC Pending:</span> 
                            Please complete your KYC immediately to start investing in campaigns
                        </p>

                        <div>
                            <button className='py-[9px] px-[16px] bg-[#222] text-white text-[12px] font-[500] rounded-[4px]'>Complete KYC</button>
                        </div>
                </div> */}

                {/* <div className='w-full min-h-[100vh] pb-[60px] pl-[40px] pr-[42px] relative'> */}

                {/* <div className='pt-[12px] mb-[20px] w-full'> */}
                    <StartupCards  startups={fetchedData}/>

                {/* </div> */}
                {/* </div> */}

                   
            </div>
    </div>
      
    </>
  )
}


const StartupCards = ({ startups }) => {
    console.log("fdfdfdfd:::",startups);
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
        {startups.map((startup) => (
          <div
            key={startup._id}
            className="bg-white shadow-lg rounded-2xl p-5 border border-gray-200 hover:shadow-xl transition-shadow duration-300"
          >
            <h2 className="text-xl font-bold text-gray-800 mb-2">
              {startup.startupName || startup.companyName}
            </h2>
            <p className="text-sm text-gray-500 mb-2">
              Founded by: {startup.firstName} {startup.lastName}
            </p>
            <p className="text-sm text-gray-600 mb-1">
              📍 Location: {startup.location || "Not specified"}
            </p>
            <p className="text-sm text-gray-600 mb-1">
              🏭 Industry: {startup.industry || "Not specified"}
            </p>
            <p className="text-sm text-gray-600 mb-1">
              💼 Stage: {startup.stage || "Not specified"}
            </p>
            <p className="text-sm text-gray-600 mb-1">
              👥 Team Size: {startup.currentTeamSize}
            </p>
            <p className="text-sm text-gray-600 mb-1">
              💸 Revenue: ₹{startup.revenue}
            </p>
            <p className="text-sm text-gray-600 mb-1">
              📈 MVP: {startup.mvp}
            </p>
  
            <div className="mt-4 flex flex-wrap gap-3">
              <a
                href={startup.companyWebsite}
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 hover:underline text-sm"
              >
                🌐 Website
              </a>
              <a
                href={startup.companyLinkedIn}
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 hover:underline text-sm"
              >
                🔗 LinkedIn
              </a>
              <a
                href={startup.founderLinkedIn}
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 hover:underline text-sm"
              >
                👤 Founder
              </a>
            </div>
  
            <div className="mt-4 text-sm text-gray-700">
              <p className="font-semibold">Product Description:</p>
              <p className="text-gray-600">{startup.describeProduct}</p>
            </div>
          </div>
        ))}
      </div>
    );
  };
  
export default InvesterStartUpDetails;
