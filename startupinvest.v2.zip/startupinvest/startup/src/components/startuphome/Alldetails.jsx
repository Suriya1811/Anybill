import React, { useEffect, useState } from "react";

const Alldetails = () => {
  const host = "http://localhost:5000";
  const [startup, setStartup] = useState(null); // State to store startup data
  const [error, setError] = useState(null); // State to store errors

  useEffect(() => {
    const startupId = localStorage.getItem("registeredId");

    if (!startupId) {
      setError("No ID found in localStorage");
      return;
    }

    const fetchStartup = async () => {
      try {
        const response = await fetch(`${host}/api/startup/getStartupById/${startupId}`);

        if (!response.ok) {
          throw new Error(`Error: ${response.status} - ${response.statusText}`);
        }

        const data = await response.json();
        setStartup(data);
      } catch (err) {
        console.error("Error fetching startup:", err);
        setError("Failed to fetch startup data");
      }
    };

    fetchStartup();
  }, []);

  if (error) {
    return <div className="text-red-500 text-center mt-4">Error: {error}</div>;
  }

  if (!startup) {
    return <div className="text-blue-500 text-center mt-4">Loading...</div>;
  }

  return (
    <div className="bg-green-50 min-h-screen py-8 px-4">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-800 mb-6 text-center">
          Startup Details
        </h1>

        {/* Grid Layout for Two Columns */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Personal Information */}
          <div className="bg-white p-6 shadow rounded-lg">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">
              Personal Information
            </h2>
            <p>
              <strong>First Name:</strong> {startup.firstName}
            </p>
            <p>
              <strong>Last Name:</strong> {startup.lastName}
            </p>
            <p>
              <strong>Email:</strong> {startup.email}
            </p>
            <p>
              <strong>Number:</strong> {startup.number}
            </p>
            <p>
              <strong>Founder LinkedIn:</strong>{" "}
              <a
                href={startup.founderLinkedIn}
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-500 hover:underline"
              >
                {startup.founderLinkedIn}
              </a>
            </p>
          </div>

          {/* Company Information */}
          <div className="bg-white p-6 shadow rounded-lg">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">
              Company Information
            </h2>
            <p>
              <strong>Company Name:</strong> {startup.companyName}
            </p>
            <p>
              <strong>Company Website:</strong>{" "}
              <a
                href={`https://${startup.companyWebsite}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-500 hover:underline"
              >
                {startup.companyWebsite}
              </a>
            </p>
            <p>
              <strong>Company LinkedIn:</strong>{" "}
              <a
                href={startup.companyLinkedIn}
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-500 hover:underline"
              >
                {startup.companyLinkedIn}
              </a>
            </p>
            <p>
              <strong>Size of Team:</strong> {startup.sizeOfTeam}
            </p>
            <p>
              <strong>Revenue:</strong> {startup.revenue}
            </p>
          </div>

          {/* Product and Funding */}
          <div className="bg-white p-6 shadow rounded-lg">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">
              Product and Funding
            </h2>
            <p>
              <strong>Describe Product:</strong> {startup.describeProduct}
            </p>
            <p>
              <strong>Previous Funding Round:</strong>{" "}
              {startup.describePreviousFundingRound}
            </p>
            <p>
              <strong>Why Community Round:</strong> {startup.whyCommunityRound}
            </p>
            <p>
              <strong>Existing Commitments:</strong>{" "}
              {startup.existingCommitments}
            </p>
          </div>

          {/* Startup Overview */}
          <div className="bg-white p-6 shadow rounded-lg">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">
              Startup Overview
            </h2>
            <p>
              <strong>Startup Name:</strong> {startup.startupName}
            </p>
            <p>
              <strong>Founders Details:</strong> {startup.foundersdetails}
            </p>
            <p>
              <strong>Industry:</strong> {startup.industry}
            </p>
            <p>
              <strong>Location:</strong> {startup.location}
            </p>
            <p>
              <strong>Stage:</strong> {startup.stage}
            </p>
            <p>
              <strong>MVP:</strong> {startup.mvp}
            </p>
            <p>
              <strong>Is Service in the Market:</strong>{" "}
              {String(startup.isServiceIntheMarket)}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Alldetails;
