import React, { useState, useRef, useCallback, useEffect } from "react";
import Stnavbar from '../startuphome/Nvbrforhome'
import logo from './Logo.png'

const Startupmainhomepage = () => {
     const host = "http://localhost:5000";
    
        const [investorData, setInvestorData] = useState(null);
        const [investorList, setInvestorList] = useState([]);
        async function getInvestorById(id) {
            try {
                // Make a request to the endpoint using the provided ID
                const response = await fetch(`${host}/api/startup/getStartupById/${id}`);
        
                // Check if the response is successful
                if (!response.ok) {
                    throw new Error(`Error: ${response.statusText}`);
                }
        
                // Parse the response JSON
                const data = await response.json();
        
                // Set the retrieved data in state
                setInvestorData(data);
        
                // Log the response data
                console.log('Investor Data:', data);
            } catch (error) {
                console.error('Error fetching investor data:', error);
            }
        }
        
        useEffect(() => {
            // Retrieve the investor ID from localStorage
            const investorId = localStorage.getItem('registeredId');
        
            if (investorId) {
                getInvestorById(investorId); // Call the function with the retrieved ID
            } else {
                console.error('No investor ID found in localStorage');
            }
        }, []); // Empty dependency array to run the effect only once

        useEffect(()=>{
            const controller = new AbortController();
            const signal = controller.signal;
            const getData = ()=>{
                fetch(`${host}/api/investor/investors`,{
                    method:'GET',
                    headers:{
                        'Content-Type': 'json/application',
                    },
                    signal
                }).then(response=>{
                    return response.json();
                }).then(data=>{
                    console.log(data)
                    setInvestorList(data);
                }
                ).catch(err=>console.error(err));
            }
            getData();

            return(()=>{
                controller.abort();
            })
        }
        ,[setInvestorList])
  return (
    <>
    <Stnavbar/>
    
    <div className='font-[400] text-black text-[12px] bg-green-100 h-full min-h-[100vh] pb-[80px] pt-[160px]'>
        <div className='h-full flex items-center justify-center '>
            <div className='h-full flex items-start justify-center'>
                <div className='min-h-[300px] flex items-center'>
                    <div className='w-full max-w-[1360px] px-[9px]'>
    
                        <div>
                            <div className='mb-[36px] mt-[20px] px-[9px] flex justify-center items-center'>
                                <a href="">
                                    <img src={logo} alt="" className='w-full h-auto'/>
                                </a>
                            </div>
                        </div>

    
                        <div>
                            <div className='px-[9px] mt-[95px] flex flex-col items-center'>
                                <h1 className='max-w-[534px] text-[26px] font-[400] text-center'><span className='font-[500]'>Thank your</span> You have successfully completed KYC and registered as a Startup with Venture Loop. We will contact you soon</h1>
    
                            </div>
                            
                            <div className='mt-[32px] flex items-center flex-col'>
                                <div className='mt-[3rem]'>
    
                                {/* <div className='flex w-full justify-center mt-[50px]'>
                                    <Link to='/investorlogin' className='flex flex-wrap justify-center items-center mt-[10px]'>
                                        <button className='bg-[#222] border-[1px] border-[#222] rounded-[2px] w-[180px] py-[12px] px[24px] text-white text-[13px] font-[500] shadow-custom4 p-4'>Go To Login</button>
                                    </Link>
                                </div> */}
                                
                                </div>
                            </div>
                            
                            
                        </div>
                        
                    </div>
                </div>
            </div> 
        </div>
        </div> 
                                    
        <div className="flex flex-wrap  gap-6 px-4 py-8 bg-gray-50 dark:bg-gray-900 min-h-500">
            {investorList.map((inv) => (
                <InvestorCard key={inv._id} investor={inv} />
            ))}
        </div>
</>
  )
}

const InvestorCard = ({ investor }) => {
    return (
      <div className="bg-white dark:bg-gray-800 shadow-md rounded-2xl p-6 m-4 w-full max-w-md transition hover:scale-[1.01]">
        <h2 className="text-xl font-bold text-blue-600 dark:text-blue-400 mb-2">
          {investor.yourName || `${investor.firstName} ${investor.lastName}`}
        </h2>
  
        <div className="text-sm text-gray-700 dark:text-gray-300 space-y-1">
          <p><span className="font-semibold">Email:</span> {investor.email}</p>
          <p><span className="font-semibold">Phone:</span> {investor.number}</p>
          <p><span className="font-semibold">Location:</span> {investor.georaphicalRegionsYouFocusForInvest || 'N/A'}</p>
          <p><span className="font-semibold">Firm:</span> {investor.whichFirmDoYouRepresent || 'N/A'}</p>
          <p><span className="font-semibold">Investment Type:</span> {investor.investAsIndividualOrAsFirm}</p>
          <p><span className="font-semibold">Interest:</span> {investor.industriesOfInterest}</p>
          <p><span className="font-semibold">Stage:</span> {investor.stageOfStartupsYouInvest}</p>
          <p><span className="font-semibold">Equity Aim:</span> {investor.whatPercentageOfEquityDoYouAim}%</p>
          <p><span className="font-semibold">Range:</span> ₹{investor.investmentrange}</p>
          <p><span className="font-semibold">Open to SAFE:</span> {investor.aeYouOpenToConevrtibleNotesOrSAFEs}</p>
          <p><span className="font-semibold">Follow-on Funding:</span> {investor.doYouOfferFollowonFunding}</p>
          <p className="text-xs text-gray-400 dark:text-gray-500 mt-2">
            Joined: {new Date(investor.createdAt).toLocaleDateString()}
          </p>
        </div>
      </div>
    );
  };

export default Startupmainhomepage
