import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom'
import flag from '../Profileopt/flag.svg'
import arrow from '../Profileopt/arrow (2).svg'
import logo from './Logo.png'


const investorsignup = () => {

    const host = "http://localhost:5000";

    const [formData, setFormData] = useState({
        number: '',
        email: '',
        password: '',
        confirmPassword: '',
    });


    const [otp, setOtp] = useState("");
    const [otpSent, setOtpSent] = useState(false);
    const [otpVerified, setOtpVerified] = useState(false);
    const [countryCode, setCountryCode] = useState("+91");
    const [errors, setErrors] = useState([]);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [otpMessage, setOtpMessage] = useState("");
    const [timer, setTimer] = useState(0);





    const navigate = useNavigate()



    useEffect(() => {
        if (timer > 0) {
            const interval = setInterval(() => setTimer((prev) => prev - 1), 1000);
            return () => clearInterval(interval);
        }
    }, [timer]);



    const handleInputChange = (e) => {
        const { name, value } = e.target;
        if (name === "number" || name === "otp") {
          if (!/^\d*$/.test(value)) return;
        }
        setFormData((prev) => ({
          ...prev,
          [name]: value,
        }));
        if (name === "otp") {
          setOtp(value);
        }
      };





      const sendOtp = async () => {
        if (!formData.number || formData.number.length !== 10) {
          setErrors(["Please enter a valid 10-digit phone number."]);
          return;
        }
    
        try {
          const response = await fetch(`${host}/send-otp`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ phoneNumber: `${countryCode}${formData.number}` }),
          });
    
          const data = await response.json();
    
          if (response.ok) {
            setOtpSent(true);
            setOtpMessage(`OTP sent to ${countryCode}*******${formData.number.slice(-3)}`);
            setTimer(60);
          } else {
            setErrors([data.message || "Failed to send OTP."]);
          }
        } catch {
          setErrors(["Failed to send OTP. Please try again."]);
        }
      };
    
      const verifyOtp = async () => {
        if (!otp) {
          setErrors(["Please enter the OTP."]);
          return;
        }
    
        try {
          const response = await fetch(`${host}/verify-otp`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ phoneNumber: `${countryCode}${formData.number}`, otp }),
          });
    
          const data = await response.json();
    
          if (response.ok) {
            setOtpVerified(true);
            setOtpMessage("OTP verified successfully!");
            setErrors([]);
          } else {
            setErrors([data.message || "Invalid OTP."]);
          }
        } catch {
          setErrors(["Failed to verify OTP. Please try again."]);
        }
      };



    const validateForm = () => {
        let formErrors = [];

        // if (!formData.phoneNumber || !/^\d{10}$/.test(formData.phoneNumber)) {
        //     formErrors.push("Please enter a valid 10-digit phone number.");
        // }

        if (!formData.email || !/\S+@\S+\.\S+/.test(formData.email)) {
            formErrors.push("Please enter a valid email address.");
        }

        if (!formData.password || formData.password.length < 8) {
            formErrors.push("Password must be at least 8 characters.");
        }

        if (formData.password !== formData.confirmPassword) {
            formErrors.push("Passwords do not match.");
        }

        return formErrors;
    };



    const handleSubmit = async (e) => {
        e.preventDefault();
        setErrors([]);
        const validationErrors = validateForm();

        if (validationErrors.length > 0) {
            setErrors(validationErrors);
            return;
        }

        setIsSubmitting(true);

        console.log(formData);

        try {
            const response = await fetch(`${host}/api/investor`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    number: formData.number,
                    email: formData.email,
                    password: formData.password,
                    firstName: 'John', // Replace 'NA' with actual values
                    lastName: 'Doe',
                    gender: 'Male', // Must be 'Male', 'Female', or 'Other'
                    dob: '1990-01-01',
                    maritalStatus: 'Single', // Must be 'Single', 'Married', etc.
                    annualGrossIncome: '+1Cr', // Example value
                    currentResidentialStatus: 'indian', // Must be 'Owner', 'Rented', etc.
                    pincode: '123456',
                    panCardNumber: 'ABCDE1234F', // A valid PAN card format
                    aadharCardNumber: '123456789012', // A valid 12-digit Aadhar number
                    ifscCode: 'ABCD0123456', // A valid IFSC code
                    accountNumber: '123456789012', // A valid account number
                    iAccept: 'true', // Must be 'true'
                    isEighteenOrOlder: 'true', // Must be 'true'
                }),
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.errors ? data.errors.map(err => err.msg).join(', ') : data.error);
            }

            localStorage.setItem('registeredEmail', formData.email);

            // Redirect to /investorsignuptwo after successful registration
            navigate('/inverstorsignuptwo');

            // Handle success, e.g., redirect or show success message
              alert('Registration successful!');
        } catch (error) {
            // Handle error
            console.error(error.message);
            alert('An error occurred during registration.');
        } finally {
            setIsSubmitting(false);
        }
    };


    return (
        <>
            <div className="font-[400] text-black text-[12px] bg-green-100 h-full">
                <div className="h-full flex items-center justify-center">
                    <div className="min-h-[1000px] flex items-center">
                        <div className="w-full max-w-[1360px] px-[9px]">
                            <div className="mb-[36px] mt-[20px] px-[9px] flex justify-center items-center">
                                <img src={logo} alt="Logo" className="w-full h-auto" />
                            </div>
                            <div className="mt-[95px] px-[9px] flex justify-center">
                                <h1 className="max-w-[534px] text-[26px] font-[300] text-center">
                                    I want to <strong>signup</strong> as an <strong>Investor</strong>
                                </h1>
                            </div>
                            <div className="mt-[32px] flex items-center flex-col">
                                <form onSubmit={handleSubmit} className="flex flex-col items-start">
                                    <div className="mb-[20px] px-[9px]">
                                        <label className="text-[14px] font-[500]">Phone Number</label>
                                        <div className="flex items-center border-[1px] border-[#b7b7b7] mt-[3px]">
                                            <select
                                                value={countryCode}
                                                onChange={(e) => setCountryCode(e.target.value)}
                                                disabled={otpVerified}
                                                className="bg-[#f5f5f5] w-[80px] h-[48px] text-[12px] font-medium border-[#cacaca] p-[12px] rounded-l-[4px]"
                                            >
                                                <option value="+91">+91 (India)</option>
                                                <option value="+1">+1 (USA)</option>
                                                <option value="+44">+44 (UK)</option>
                                                <option value="+61">+61 (Australia)</option>
                                            </select>
                                            <input
                                                type="text"
                                                name="number"
                                                value={formData.number}
                                                onChange={handleInputChange}
                                                placeholder="Enter your phone number"
                                                disabled={otpVerified}
                                                className="bg-white w-full h-[48px] text-[12px] font-medium border-[#cacaca] p-[12px] rounded-r-[4px]"
                                            />
                                        </div>
                                        {!otpVerified && (
                                            <div className="mt-[10px]">
                                                {timer > 0 ? (
                                                    <span className="text-gray-500">
                                                        Resend OTP in {timer} seconds
                                                    </span>
                                                ) : (
                                                    <button
                                                        type="button"
                                                        className="bg-[#222] text-white px-[10px] py-[5px] rounded-[4px]"
                                                        onClick={sendOtp}
                                                    >
                                                        {otpSent ? "Resend OTP" : "Send OTP"}
                                                    </button>
                                                )}
                                            </div>
                                        )}
                                        {otpMessage && <div className="text-green-600 text-xs mt-2">{otpMessage}</div>}
                                    </div>
                                    {otpSent && !otpVerified && (
                                        <div className="mb-[20px] px-[9px]">
                                            <label className="text-[14px] font-[500]">Enter OTP</label>
                                            <input
                                                type="text"
                                                value={otp}
                                                onChange={(e) => handleInputChange({ target: { name: "otp", value: e.target.value } })}
                                                placeholder="Enter the OTP"
                                                className="bg-white w-full h-[48px] text-[12px] font-medium border-[#cacaca] p-[12px]"
                                            />
                                            <button
                                                type="button"
                                                className="bg-[#222] text-white px-[10px] py-[5px] mt-[10px] rounded-[4px]"
                                                onClick={verifyOtp}
                                            >
                                                Verify OTP
                                            </button>
                                        </div>
                                    )}
                                    <div className="mb-[20px] px-[9px]">
                                        <label className="text-[14px] font-[500]">Email ID</label>
                                        <input
                                            type="email"
                                            name="email"
                                            value={formData.email}
                                            onChange={handleInputChange}
                                            placeholder="Enter your email"
                                            className="bg-white w-full h-[48px] text-[12px] font-medium border-[#cacaca] p-[12px]"
                                        />
                                    </div>
                                    <div className="mb-[20px] px-[9px]">
                                        <label className="text-[14px] font-[500]">Create Password</label>
                                        <input
                                            type="password"
                                            name="password"
                                            value={formData.password}
                                            onChange={handleInputChange}
                                            placeholder="Enter your password"
                                            className="bg-white w-full h-[48px] text-[12px] font-medium border-[#cacaca] p-[12px]"
                                        />
                                    </div>
                                    <div className="mb-[20px] px-[9px]">
                                        <label className="text-[14px] font-[500]">Confirm Password</label>
                                        <input
                                            type="password"
                                            name="confirmPassword"
                                            value={formData.confirmPassword}
                                            onChange={handleInputChange}
                                            placeholder="Re-enter your password"
                                            className="bg-white w-full h-[48px] text-[12px] font-medium border-[#cacaca] p-[12px]"
                                        />
                                    </div>
                                    {errors.length > 0 && (
                                        <div className="text-red-500 text-xs mt-2">
                                            {errors.map((error, index) => (
                                                <p key={index}>{error}</p>
                                            ))}
                                        </div>
                                    )}
                                    <div className="mt-[20px]">
                                        <button
                                            type="submit"
                                            className={`${isSubmitting ? "bg-gray-500" : "bg-[#222]"
                                                } text-white px-[20px] py-[10px] rounded-[4px]`}
                                            disabled={isSubmitting}
                                        >
                                            {isSubmitting ? "Submitting..." : "Sign Up"}
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default investorsignup
