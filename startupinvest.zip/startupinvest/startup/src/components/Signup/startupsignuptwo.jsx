import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom'
import flag from '../Profileopt/flag.svg'
import arrow from '../Profileopt/arrow (2).svg'
import logo from './Logo.png'


const startupsignuptwo = () => {

    const host = "http://localhost:5000";

    const [formData, setFormData] = useState({
        number: '',
        email: '',
        password: '',
        confirmPassword: '',
    });


    const [otp, setOtp] = useState("");
    const [otpSent, setOtpSent] = useState(false);
    const [otpVerified, setOtpVerified] = useState(false);
    const [countryCode, setCountryCode] = useState("+91");
    const [errors, setErrors] = useState({});
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [otpMessage, setOtpMessage] = useState("");
    const [timer, setTimer] = useState(0);

    const navigate = useNavigate()

    useEffect(() => {
        if (timer > 0) {
          const interval = setInterval(() => setTimer((prev) => prev - 1), 1000);
          return () => clearInterval(interval);
        }
      }, [timer]);

      const handleInputChange = (e) => {
        const { name, value } = e.target;
        if (name === "number" || name === "otp") {
          if (!/^\d*$/.test(value)) return; // Restrict non-numeric input
        }
        setFormData((prev) => ({
          ...prev,
          [name]: value,
        }));
        if (name === "otp") {
          setOtp(value); // Update OTP state for the OTP field
        }
      };




      const sendOtp = async () => {
        if (!formData.number || formData.number.length !== 10) {
          setErrors((prev) => ({ ...prev, number: "Please enter a valid 10-digit phone number." }));
          return;
        }
    
        try {
          const response = await fetch(`${host}/send-otp`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ phoneNumber: `${countryCode}${formData.number}` }),
          });
    
          const data = await response.json();
    
          if (response.ok) {
            setOtpSent(true);
            setOtpMessage(`OTP sent to ${countryCode}*******${formData.number.slice(-3)}`);
            setTimer(60); // Start 1-minute timer
            setErrors((prev) => ({ ...prev, number: "" }));
          } else {
            setErrors((prev) => ({ ...prev, number: data.message || "Failed to send OTP." }));
          }
        } catch {
          setErrors((prev) => ({ ...prev, number: "Failed to send OTP. Please try again." }));
        }
      };
    
      const verifyOtp = async () => {
        if (!otp) {
          setErrors((prev) => ({ ...prev, otp: "Please enter the OTP." }));
          return;
        }
    
        try {
          const response = await fetch(`${host}/verify-otp`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ phoneNumber: `${countryCode}${formData.number}`, otp }),
          });
    
          const data = await response.json();
    
          if (response.ok) {
            setOtpVerified(true);
            setOtpMessage("OTP verified successfully!");
            setErrors((prev) => ({ ...prev, otp: "" }));
          } else {
            setErrors((prev) => ({ ...prev, otp: data.message || "Invalid OTP." }));
          }
        } catch {
          setErrors((prev) => ({ ...prev, otp: "Failed to verify OTP. Please try again." }));
        }
      };
    




    const validateForm = () => {
        let formErrors = [];

        if (!formData.number || !/^\d{10}$/.test(formData.number)) {
            formErrors.push("Please enter a valid 10-digit phone number.");
        }

        if (!formData.email || !/\S+@\S+\.\S+/.test(formData.email)) {
            formErrors.push("Please enter a valid email address.");
        }

        if (!formData.password || formData.password.length < 8) {
            formErrors.push("Password must be at least 8 characters.");
        }

        if (formData.password !== formData.confirmPassword) {
            formErrors.push("Passwords do not match.");
        }

        return formErrors;
    };


    const handleSubmit = async (e) => {
        e.preventDefault();
        setErrors([]);
        const validationErrors = validateForm();

        if (Object.keys(validationErrors).length > 0) {
            setErrors(validationErrors);
            return;
          }

          localStorage.setItem("startupemail",formData.email);
        setIsSubmitting(true);
        console.log("formdata: ",formData)

        try {
            const response = await fetch(`${host}/api/startup`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(formData),
            });
      
            if (response.ok) {
              alert("Registration successful!");
              navigate("/startupsignup");
            } else {
              alert("Registration failed. Please try again.");
            }
          } catch {
            alert("An error occurred during registration.");
          } finally {
            setIsSubmitting(false);
          }
    };


    return (
        <>
            <div className="font-[400] text-black text-[12px] bg-green-100 h-full">
                <div className="h-full flex items-center justify-center">
                    <div className="min-h-[1000px] flex items-center">
                        <div className="w-full max-w-[1360px] px-[9px]">
                            <div className="mb-[36px] mt-[20px] px-[9px] flex justify-center items-center">
                                <img src={logo} alt="" className="w-full h-auto" />
                            </div>
                            <div className="mt-[95px] px-[9px] flex justify-center">
                                <h1 className="max-w-[534px] text-[26px] font-[300] text-center">
                                    I want to <strong>signup</strong> as a <strong>Startup</strong>
                                </h1>
                            </div>
                            <div className="mt-[32px] flex items-center flex-col">
                                <form onSubmit={handleSubmit} className="flex flex-col items-start">
                                    {/* Phone Number */}
                                    <div className="mb-[20px] px-[9px]">
                                        <label className="text-[14px] font-[500]">Phone Number</label>
                                        <div className="flex items-center border-[1px] border-[#b7b7b7] mt-[3px]">
                                            <select
                                                value={countryCode}
                                                onChange={(e) => setCountryCode(e.target.value)}
                                                disabled={otpVerified}
                                                className="bg-[#f5f5f5] w-[80px] h-[48px] text-[12px] font-medium border-[#cacaca] p-[12px] rounded-l-[4px]"
                                            >
                                                <option value="+91">+91 (India)</option>
                                                <option value="+1">+1 (USA)</option>
                                                <option value="+44">+44 (UK)</option>
                                                <option value="+61">+61 (Australia)</option>
                                            </select>
                                            <input
                                                type="text"
                                                name="number"
                                                value={formData.number}
                                                onChange={handleInputChange}
                                                placeholder="Enter your phone number"
                                                disabled={otpVerified}
                                                className="bg-white w-full h-[48px] text-[12px] font-medium border-[#cacaca] p-[12px] rounded-r-[4px]"
                                            />
                                        </div>
                                        {errors.number && <div className="text-red-500 text-xs mt-1">{errors.number}</div>}
                                        {!otpVerified && (
                                            <div className="mt-[10px]">
                                                {timer > 0 ? (
                                                    <span className="text-gray-500">Resend OTP in {timer} seconds</span>
                                                ) : (
                                                    <button
                                                        type="button"
                                                        className="bg-[#222] text-white px-[10px] py-[5px] rounded-[4px]"
                                                        onClick={sendOtp}
                                                    >
                                                        {otpSent ? "Resend OTP" : "Send OTP"}
                                                    </button>
                                                )}
                                            </div>
                                        )}
                                        {otpMessage && <div className="text-green-600 text-xs mt-2">{otpMessage}</div>}
                                    </div>

                                    {/* OTP Verification */}
                                    {otpSent && !otpVerified && (
                                        <div className="mb-[20px] px-[9px]">
                                            <label className="text-[14px] font-[500]">Enter OTP</label>
                                            <input
                                                type="text"
                                                value={otp}
                                                onChange={(e) => handleInputChange({ target: { name: "otp", value: e.target.value } })}
                                                placeholder="Enter the OTP"
                                                className="bg-white w-full h-[48px] text-[12px] font-medium border-[#cacaca] p-[12px]"
                                            />
                                            <button
                                                type="button"
                                                className="bg-[#222] text-white px-[10px] py-[5px] mt-[10px] rounded-[4px]"
                                                onClick={verifyOtp}
                                            >
                                                Verify OTP
                                            </button>
                                            {errors.otp && <div className="text-red-500 text-xs mt-1">{errors.otp}</div>}
                                        </div>
                                    )}

                                    {/* Email */}
                                    <div className="mb-[20px] px-[9px]">
                                        <label className="text-[14px] font-[500]">Email ID</label>
                                        <input
                                            type="email"
                                            name="email"
                                            value={formData.email}
                                            onChange={handleInputChange}
                                            placeholder="Enter your email"
                                            className="bg-white w-full h-[48px] text-[12px] font-medium border-[#cacaca] p-[12px]"
                                        />
                                        {errors.email && <div className="text-red-500 text-xs mt-1">{errors.email}</div>}
                                    </div>

                                    {/* Password */}
                                    <div className="mb-[20px] px-[9px]">
                                        <label className="text-[14px] font-[500]">Create Password</label>
                                        <input
                                            type="password"
                                            name="password"
                                            value={formData.password}
                                            onChange={handleInputChange}
                                            placeholder="Enter your password"
                                            className="bg-white w-full h-[48px] text-[12px] font-medium border-[#cacaca] p-[12px]"
                                        />
                                        {errors.password && <div className="text-red-500 text-xs mt-1">{errors.password}</div>}
                                    </div>

                                    {/* Confirm Password */}
                                    <div className="mb-[20px] px-[9px]">
                                        <label className="text-[14px] font-[500]">Confirm Password</label>
                                        <input
                                            type="password"
                                            name="confirmPassword"
                                            value={formData.confirmPassword}
                                            onChange={handleInputChange}
                                            placeholder="Re-enter your password"
                                            className="bg-white w-full h-[48px] text-[12px] font-medium border-[#cacaca] p-[12px]"
                                        />
                                        {errors.confirmPassword && (
                                            <div className="text-red-500 text-xs mt-1">{errors.confirmPassword}</div>
                                        )}
                                    </div>

                                    {/* Submit Button */}
                                    <div className="mt-[20px]">
                                        <button
                                            type="submit"
                                            className={`${isSubmitting ? "bg-gray-500" : "bg-[#222]"
                                                } text-white px-[20px] py-[10px] rounded-[4px]`}
                                            disabled={isSubmitting}
                                        >
                                            {isSubmitting ? "Submitting..." : "Sign Up"}
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </>
    )
}

export default startupsignuptwo
