var jwt = require('jsonwebtoken');
const JWT_SECRET = 'Yuf%@VC67V%^&EV^%672bvbv6e2'

const fetchinvestor = (req, res, next)=>{

    const token = req.header('auth-token');
    if(!token){
        return res.status(401).json({ error: 'Use correct token' });
    }

    try {
        const data = jwt.verify(token, JWT_SECRET);
        req.investor = data.investor;
        next()
    } catch (err) {
        console.error(err.message);
        res.status(401).json({ message: 'Wrong credentials' });
    }
}

module.exports = fetchinvestor;