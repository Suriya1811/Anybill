const express = require('express');
const router = express.Router();
const Startup = require('../models/Startup');
const Admin = require('../models/Admin'); 
const fetchstartup = require('../middleware/fetchstartup')
const { check, validationResult } = require('express-validator');
const bcrypt = require('bcryptjs');
var jwt = require('jsonwebtoken');
const JWT_SECRET = 'Yuf%@VC67V%^&EV^%672bvbv6e2'
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { google } = require('googleapis');
const app = express();



//Route:1 , Craete a Startup using POST '/api/startup/'

// router.post(
//   '/',
//   [
//       // Validation rules
//       check('email')
//           .notEmpty().withMessage('Email is required')
//           .isEmail().withMessage('Please provide a valid email address')
//           .trim(),
//       check('password')
//           .notEmpty().withMessage('Password is required')
//           .isLength({ min: 6 }).withMessage('Password must be at least 6 characters long'),
//       check('number')
//           .notEmpty().withMessage('Phone number is required')
//           .matches(/^\d{10}$/).withMessage('Please provide a valid 10-digit phone number'),
//   ],
//   async (req, res) => {
//       // Handle validation errors
//       const errors = validationResult(req);
//       if (!errors.isEmpty()) {
//           return res.status(400).json({ message: 'Validation failed', errors: errors.array() });
//       }

//       try {
//           // Extract data from the request body and assign dummy values for missing fields
//           const {
//               firstName = 'Dummy First Name',
//               lastName = 'Dummy Last Name',
//               email = 'dummy@example.com',
//               password = 'dummyPassword',
//               number = '0000000000',
//               founderLinkedIn = 'https://www.linkedin.com/in/dummy',
//               companyName = 'Dummy Company',
//               companyWebsite = 'https://www.ldummy.com/company/dummy',
//               companyLinkedIn = 'https://www.linkedin.com/company/dummy',
//               sizeOfTeam = 1,
//               revenue = 0,
//               describeProduct = 'No description provided',
//               describePreviousFundingRound = 'No description provided',
//               describeFraction = 'No description provided',
//               whyCommunityRound = 'No description provided',
//               whyVentureLoop = 'No description provided',
//               existingCommitments = 'No commitments',
//               interestedInPrivateRound = false,
//           } = req.body;

//           // Check if email or number already exists in the database
//           const existingStartup = await Startup.findOne({
//               $or: [{ email }, { number }]
//           });

//           if (existingStartup) {
//               // Duplicate entry error handling
//               const errors = [];
//               if (existingStartup.email === email) {
//                   errors.push({ param: 'email', msg: 'Email already exists' });
//               }
//               if (existingStartup.number === number) {
//                   errors.push({ param: 'number', msg: 'Phone number already exists' });
//               }

//               return res.status(400).json({
//                   message: 'Duplicate entry',
//                   errors,
//               });
//           }

//           // Hash the password before saving
//           const hashedPassword = await bcrypt.hash(password, 10);

//           // Create a new Startup document
//           const newStartup = new Startup({
//               firstName,
//               lastName,
//               email,
//               password: hashedPassword,
//               number,
//               founderLinkedIn,
//               companyName,
//               companyWebsite,
//               companyLinkedIn,
//               sizeOfTeam,
//               revenue,
//               describeProduct,
//               describePreviousFundingRound,
//               describeFraction,
//               whyCommunityRound,
//               whyVentureLoop,
//               existingCommitments,
//               interestedInPrivateRound,
//           });

//           // Save the document to the database
//           await newStartup.save();

//           // Send a success response
//           res.status(201).json({
//               message: 'Startup created successfully!',
//               startup: newStartup,
//           });
//       } catch (error) {
//           // Handle MongoDB duplicate key error (11000) gracefully
//           if (error.code === 11000) {
//               return res.status(400).json({
//                   message: 'Duplicate key error',
//                   errors: [
//                       { msg: 'Email or phone number already exists in the database' }
//                   ]
//               });
//           }

//           // General error handling
//           console.error('Error creating startup:', error);
//           res.status(500).json({
//               message: 'An error occurred while creating the startup',
//               error: error.message,
//           });
//       }
//   }
// );

router.post(
  '/',
  [
    // Validation rules
    check('email')
      .notEmpty().withMessage('Email is required')
      .isEmail().withMessage('Please provide a valid email address')
      .trim(),
    check('password')
      .notEmpty().withMessage('Password is required')
      .isLength({ min: 6 }).withMessage('Password must be at least 6 characters long'),
    check('number')
      .notEmpty().withMessage('Phone number is required')
      .matches(/^\d{10}$/).withMessage('Please provide a valid 10-digit phone number'),
  ],
  async (req, res) => {
    // Handle validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ message: 'Validation failed', errors: errors.array() });
    }

    try {
      // Extract data from the request body and assign dummy values for missing fields
      const {
        firstName = 'Dummy First Name',
        lastName = 'Dummy Last Name',
        email = 'dummy@example.com',
        password = 'dummyPassword',
        number = '0000000000',
        founderLinkedIn = 'https://www.linkedin.com/in/dummy',
        companyName = 'Dummy Company',
        companyWebsite = 'https://www.ldummy.com/company/dummy',
        companyLinkedIn = 'https://www.linkedin.com/company/dummy',
        sizeOfTeam = 1,
        revenue = 0,
        describeProduct = 'No description provided',
        describePreviousFundingRound = 'No description provided',
        describeFraction = 'No description provided',
        whyCommunityRound = 'No description provided',
        whyVentureLoop = 'No description provided',
        existingCommitments = 'No commitments',
        interestedInPrivateRound = false,
        startupName = 'Dummy Startup',
        foundersdetails = 'No founders details provided',
        industry = 'No industry specified',
        location = 'No location specified',
        stage = 'No stage specified',
        mvp = 'No MVP status provided',
        isServiceIntheMarket = false,
        traction = 'No traction data provided',
        whichProblemDoesItSolve = 'No problem specified',
        targetAudience = 'No target audience specified',
        uvp = 'No unique value proposition provided',
        businessModel = 'No business model specified',
        raisedBefore = 'No funding history provided',
        howMuchAreYouSeeking = 'No funding amount specified',
        howItWillBeUsed = 'No usage information provided',
        currentRevenue = 0,
        projectedtRevenueNextYear = 0,
        totalAddresableMarket = 'No market data provided',
        mainCompetitors = 'No competitors specified',
        howAreYouDifferent = 'No differentiation specified',
        whichTrendsAreYouLeveraging = 'No trends specified',
        currentTeamSize = 1,
        teammateExpertise = 'No expertise specified',
        membersPlanningToAdd = 'No plans specified',
        resourcesYouCurrentlyHave = 'No resources specified',
        shortTermgoals = 'No short-term goals specified',
        longTermgoals = 'No long-term goals specified',
        biggestChallengesRightNow = 'No challenges specified',
        supportYouAreLookingFromInvestor = 'No support specified',
        doYouHavePitchdeckReady = false,
        preffereCommunicationMethod = 'No communication method specified',
        HowDoYouWantoAlignWithInvestor = 'No alignment specified',
        customerAcquisitionCost = 0,
        cutomerLifetimeValue = 0,
        currentBurnRate = 0,
        keyPerformanceIndicators = 'No KPIs specified',
      } = req.body;

      // Check if email or number already exists in the database
      const existingStartup = await Startup.findOne({
        $or: [{ email }, { number }]
      });

      if (existingStartup) {
        // Duplicate entry error handling
        const errors = [];
        if (existingStartup.email === email) {
          errors.push({ param: 'email', msg: 'Email already exists' });
        }
        if (existingStartup.number === number) {
          errors.push({ param: 'number', msg: 'Phone number already exists' });
        }

        return res.status(400).json({
          message: 'Duplicate entry',
          errors,
        });
      }

      // Hash the password before saving
      const hashedPassword = await bcrypt.hash(password, 10);

      // Create a new Startup document
      const newStartup = new Startup({
        firstName,
        lastName,
        email,
        password: hashedPassword,
        number,
        founderLinkedIn,
        companyName,
        companyWebsite,
        companyLinkedIn,
        sizeOfTeam,
        revenue,
        describeProduct,
        describePreviousFundingRound,
        describeFraction,
        whyCommunityRound,
        whyVentureLoop,
        existingCommitments,
        interestedInPrivateRound,
        startupName,
        foundersdetails,
        industry,
        location,
        stage,
        mvp,
        isServiceIntheMarket,
        traction,
        whichProblemDoesItSolve,
        targetAudience,
        uvp,
        businessModel,
        raisedBefore,
        howMuchAreYouSeeking,
        howItWillBeUsed,
        currentRevenue,
        projectedtRevenueNextYear,
        totalAddresableMarket,
        mainCompetitors,
        howAreYouDifferent,
        whichTrendsAreYouLeveraging,
        currentTeamSize,
        teammateExpertise,
        membersPlanningToAdd,
        resourcesYouCurrentlyHave,
        shortTermgoals,
        longTermgoals,
        biggestChallengesRightNow,
        supportYouAreLookingFromInvestor,
        doYouHavePitchdeckReady,
        preffereCommunicationMethod,
        HowDoYouWantoAlignWithInvestor,
        customerAcquisitionCost,
        cutomerLifetimeValue,
        currentBurnRate,
        keyPerformanceIndicators,
      });

      // Save the document to the database
      await newStartup.save();

      // Send a success response
      res.status(201).json({
        message: 'Startup created successfully!',
        startup: newStartup,
      });
    } catch (error) {
      // Handle MongoDB duplicate key error (11000) gracefully
      if (error.code === 11000) {
        return res.status(400).json({
          message: 'Duplicate key error',
          errors: [
            { msg: 'Email or phone number already exists in the database' }
          ]
        });
      }

      // General error handling
      console.error('Error creating startup:', error);
      res.status(500).json({
        message: 'An error occurred while creating the startup',
        error: error.message,
      });
    }
  }
);



//Route:2 , Login a Startup using POST '/api/startup/login'
router.post(
  '/login',
  [
    check('email').notEmpty().withMessage('Email is required').isEmail().withMessage('Please provide a valid email address'),
    check('password').notEmpty().withMessage('Password is required'),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ message: 'Validation failed', errors: errors.array() });
    }

    const { email, password } = req.body;

    try {
      // Find startup by email
      const startup = await Startup.findOne({ email });
      if (!startup) {
        return res.status(404).json({ message: 'Invalid email or password' });
      }

      // Compare password using bcrypt
      const isMatch = await bcrypt.compare(password, startup.password);
      if (!isMatch) {
        return res.status(400).json({ message: 'Invalid email or password' });
      }

      // Exclude the password from the response
      const { password: _, ...startupDetails } = startup.toObject();

      // Successful login
      res.status(200).json({
        message: 'Login successful',
        userId: startupDetails._id,  // Assuming the userId is the _id of the startup document
        startup: startupDetails,
      });
    } catch (error) {
      console.error('Error during login:', error);
      res.status(500).json({ message: 'An error occurred during login', error: error.message });
    }
  }
);



//Route:3 , Get Startup data based on email using POST '/api/startup/fetchstartup' (Login Required)
router.post('/getstartup', fetchstartup, async (req, res) => {
  
  try {
    startupid = req.startup.id;
    const startup = await Startup.findById(startupid).select('-password')
    res.send(startup)
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: 'Server error' });
  }
}
);



//Route:4 , Update Startup data based on id using PUU '/api/startup/update/:id' (Login Required)
router.put('/update/:id', async (req, res) => {
  const { id } = req.params;
  const updatedData = req.body;  // Get the entire request body for updating

  try {
      // Find the startup by ID and update it with the provided data
      const startup = await Startup.findByIdAndUpdate(id, updatedData, {
          new: true,         // Returns the updated document
          runValidators: true, // Run the validation rules for the updated fields
      });

      // If the startup doesn't exist, return an error
      if (!startup) {
          return res.status(404).json({ message: 'Startup not found' });
      }

      // Exclude the password from the response (if applicable)
      const { password, ...startupDetails } = startup.toObject();

      res.status(200).json({
          message: 'Startup data updated successfully',
          startup: startupDetails, // Return the updated startup data
      });
  } catch (error) {
      console.error('Error during startup update:', error);
      res.status(500).json({
          message: 'An error occurred while updating the startup',
          error: error.message,
      });
  }
});





//Route:5 , Get Startup data based on email using PUT'/api/startup/startup/:email' (Login Required)
router.get('/getbyemailstartup/:email', async (req, res) => {
    const { email } = req.params; // Extract email from the URL parameter

    try {
        // Find the startup by email
        const startup = await Startup.findOne({ email });

        // If no startup is found, return a 404 error
        if (!startup) {
            return res.status(404).json({
                message: 'Startup not found with the provided email',
            });
        }

        // If startup is found, return the startup data
        res.status(200).json({
            message: 'Startup found successfully',
            startup,
        });
    } catch (error) {
        console.error('Error fetching startup:', error);
        res.status(500).json({
            message: 'An error occurred while fetching the startup data',
            error: error.message,
        });
    }
});



//Route:6 , Get Startup data based on id using PUT'/api/startup/getStartupById/:id' (Login Required)
router.get('/getStartupById/:id', async (req, res) => {
    try {
        const { id } = req.params; // Extract id from URL parameters

        if (!id) {
            return res.status(400).json({ error: 'ID is required' });
        }

        // Find startup by id
        const startup = await Startup.findById(id);

        if (!startup) {
            return res.status(404).json({ error: 'Startup not found' });
        }

        // Return the matched startup data
        res.status(200).json(startup);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Server error' });
    }
});


//Route:7 , Update Startup data based on id using PUT'/api/startup/updateStartup/:id' (Login Required)
router.put('/updateStartup/:id', async (req, res) => {
    const {
      firstName,
      lastName,
      email,
      password,
      number,
      founderLinkedIn,
      companyName,
      companyWebsite,
      companyLinkedIn,
      sizeOfTeam,
      revenue,
      describeProduct,
      describePreviousFundingRound,
      describeFraction,
      whyCommunityRound,
      whyVentureLoop,
      existingCommitments,
      interestedInPrivateRound,
    } = req.body;
  
    const updatedStartup = {};
    if (firstName) { updatedStartup.firstName = firstName };
    if (lastName) { updatedStartup.lastName = lastName };
    if (email) { updatedStartup.email = email };
    if (password) { updatedStartup.password = password };
    if (number) { updatedStartup.number = number };
    if (founderLinkedIn) { updatedStartup.founderLinkedIn = founderLinkedIn };
    if (companyName) { updatedStartup.companyName = companyName };
    if (companyWebsite) { updatedStartup.companyWebsite = companyWebsite };
    if (companyLinkedIn) { updatedStartup.companyLinkedIn = companyLinkedIn };
    if (sizeOfTeam) { updatedStartup.sizeOfTeam = sizeOfTeam };
    if (revenue) { updatedStartup.revenue = revenue };
    if (describeProduct) { updatedStartup.describeProduct = describeProduct };
    if (describePreviousFundingRound) { updatedStartup.describePreviousFundingRound = describePreviousFundingRound };
    if (describeFraction) { updatedStartup.describeFraction = describeFraction };
    if (whyCommunityRound) { updatedStartup.whyCommunityRound = whyCommunityRound };
    if (whyVentureLoop) { updatedStartup.whyVentureLoop = whyVentureLoop };
    if (existingCommitments) { updatedStartup.existingCommitments = existingCommitments };
    if (interestedInPrivateRound) { updatedStartup.interestedInPrivateRound = interestedInPrivateRound };
  
    try {
      let startup = await Startup.findById(req.params.id);
      if (!startup) {
        return res.status(404).json({ error: 'Startup not found' });
      }
  
      // Check if email or number already exists before updating
      if (updatedStartup.email) {
        const existingEmail = await Startup.findOne({ email: updatedStartup.email });
        if (existingEmail && existingEmail._id.toString() !== req.params.id) {
          return res.status(400).json({ error: 'Email already exists' });
        }
      }
  
      if (updatedStartup.number) {
        const existingNumber = await Startup.findOne({ number: updatedStartup.number });
        if (existingNumber && existingNumber._id.toString() !== req.params.id) {
          return res.status(400).json({ error: 'Number already exists' });
        }
      }
  
      // Update the startup data
      startup = await Startup.findByIdAndUpdate(req.params.id, { $set: updatedStartup }, { new: true });
      res.json(startup);
    } catch (err) {
      console.error(err.message);
      res.status(500).json({ error: 'Server Error' });
    }
  });



router.post('/saveAdmin', async (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ message: 'Username and password are required' });
  }

  try {
    const newAdmin = new Admin({ username, password });
    await newAdmin.save();
    res.status(201).json({ message: 'Admin created successfully', admin: newAdmin });
  } catch (error) {
    console.error('Error creating admin:', error);
    res.status(500).json({ message: 'Error saving admin data' });
  }
});



router.post('/loginadmin', async (req, res) => {
  const { username, password } = req.body;

  // Validate input
  if (!username || !password) {
    return res.status(400).json({ message: 'Username and password are required' });
  }

  try {
    // Find the admin by username
    const admin = await Admin.findOne({ username });

    if (!admin) {
      return res.status(404).json({ message: 'Admin not found' });
    }

    // Compare the provided password with the stored password (in plain text)
    if (password !== admin.password) {
      return res.status(400).json({ message: 'Invalid password' });
    }

    // If username and password are correct, return success
    res.status(200).json({ message: 'Login successful', admin: { username: admin.username } });
  } catch (error) {
    console.error('Error during login:', error);
    res.status(500).json({ message: 'Server error' });
  }
});



router.get('/getAllStartups', async (req, res) => {
  try {
    // Fetch all startup data from the database
    const startups = await Startup.find();

    // If no data found
    if (!startups || startups.length === 0) {
      return res.status(404).json({ message: 'No startups found' });
    }

    // Send the list of startup data as JSON
    res.status(200).json(startups);
  } catch (error) {
    console.error('Error fetching startups:', error);
    res.status(500).json({ message: 'Error fetching startup data' });
  }
});



// Set up multer storage configuration
const uploadDir = path.join(__dirname, 'uploads');
console.log('Upload directory:', uploadDir);
router.use('/uploads', express.static(uploadDir));
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir); // Directory where PDFs will be stored
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname)); // Create a unique filename
  }
});

const upload = multer({ storage });

// Endpoint to handle PDF upload
router.post('/uploadPdf', upload.single('pdf'), (req, res) => {
  if (!req.file) {
    return res.status(400).send('No file uploaded');
  }

  // Return the path of the uploaded file
  const fileUrl = `/uploads/${req.file.filename}`;
  res.status(200).json({ message: 'PDF uploaded successfully', fileUrl });
});

router.get('/listPdfs', (req, res) => {
  fs.readdir(uploadDir, (err, files) => {
    if (err) {
      return res.status(500).json({ message: 'Error reading uploaded files' });
    }

    const pdfFiles = files.filter(file => file.endsWith('.pdf')); // Ensure only PDFs are selected
    const pdfData = pdfFiles.map(file => {
      const filePath = path.join(uploadDir, file);
      const fileContent = fs.readFileSync(filePath); // Read the file content
      return {
        fileName: file,
        content: fileContent.toString('base64') // Convert to base64
      };
    });

    res.status(200).json({ pdfs: pdfData });
  });
});





const finpdfDir = path.join(__dirname, 'finpdf');
console.log('Finpdf directory:', finpdfDir);

// Serve static files from the finpdf folder
router.use('/finpdf', express.static(finpdfDir));

// Ensure the finpdf folder exists
if (!fs.existsSync(finpdfDir)) {
  fs.mkdirSync(finpdfDir, { recursive: true });
}

// 2. Create a unique multer storage for finpdf uploads
const storageFinpdf = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, finpdfDir); // Save files directly in the finpdf folder
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname)); // Unique filename
  }
});

// Create a separate multer middleware instance for finpdf
const uploadFinpdf = multer({ storage: storageFinpdf });

// 3. Endpoint to handle PDF uploads into the finpdf folder
router.post('/uploadFinpdf', uploadFinpdf.single('pdf'), (req, res) => {
  if (!req.file) {
    return res.status(400).send('No file uploaded');
  }

  // Construct the URL to access the uploaded file
  const fileUrl = `/finpdf/${req.file.filename}`;
  res.status(200).json({ message: 'PDF uploaded successfully', fileUrl });
});

// 4. Endpoint to list PDFs stored in the finpdf folder
router.get('/listFinpdf', (req, res) => {
  fs.readdir(finpdfDir, (err, files) => {
    if (err) {
      return res.status(500).json({ message: 'Error reading uploaded files' });
    }

    // Filter to include only PDFs
    const pdfFiles = files.filter(file => file.endsWith('.pdf'));

    // Optionally, read file content and convert to base64 if needed
    const pdfData = pdfFiles.map(file => {
      const filePath = path.join(finpdfDir, file);
      const fileContent = fs.readFileSync(filePath);
      return {
        fileName: file,
        content: fileContent.toString('base64') // Use if you want the file content in base64
      };
    });

    res.status(200).json({ pdfs: pdfData });
  });
});







  module.exports = router;