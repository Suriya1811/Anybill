
const connectToMongo = require('./db');
const express = require('express');
const cors = require('cors');
const twilio = require('twilio');
const Joi = require('joi');

connectToMongo();

const app = express();
const port = 5000;

// Twilio configuration
const accountSid = "ACaa87dfb4305c970166d0ec31ff8db5e3"; // Replace with your Twilio SID
const authToken = "3a06f972552e2774177afa116d9f10a0"; // Replace with your Twilio Auth Token
const serviceSid = "VAc930fb2d59d99e7b5d4e498381783eb7"; // Replace with your Twilio Verify Service SID
const client = twilio(accountSid, authToken);

// Middleware
app.use(cors());
app.use(express.json());

// Validation schemas
const phoneSchema = Joi.object({
  phoneNumber: Joi.string().pattern(/^\+[1-9]\d{1,14}$/).required(), // E.164 phone number format
});

const otpSchema = Joi.object({
  phoneNumber: Joi.string().pattern(/^\+[1-9]\d{1,14}$/).required(),
  otp: Joi.string().length(6).required(),
});

// API to send OTP
app.post('/send-otp', async (req, res) => {
  const { error } = phoneSchema.validate(req.body);
  if (error) {
    return res.status(400).json({ success: false, message: error.details[0].message });
  }

  const { phoneNumber } = req.body;

  try {
    const response = await client.verify.v2
      .services(serviceSid)
      .verifications.create({ to: phoneNumber, channel: 'sms' });
    res.json({ success: true, message: 'OTP sent successfully.' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// API to verify OTP
app.post('/verify-otp', async (req, res) => {
  const { error } = otpSchema.validate(req.body);
  if (error) {
    return res.status(400).json({ success: false, message: error.details[0].message });
  }

  const { phoneNumber, otp } = req.body;

  try {
    const response = await client.verify.v2
      .services(serviceSid)
      .verificationChecks.create({ to: phoneNumber, code: otp });

    if (response.status === 'approved') {
      res.json({ success: true, message: 'OTP verified successfully.' });
    } else {
      res.status(400).json({ success: false, message: 'Invalid OTP.' });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Available Routes
app.get('/', (req, res) => {
  res.send('Hello World!');
});

app.use('/api/partner', require('./routes/partner'));
app.use('/api/investor', require('./routes/investor'));
app.use('/api/startup', require('./routes/startup'));

app.listen(port, () => {
  console.log(`Example app listening on port http://localhost:${port}`);
});
