const mongoose = require('mongoose');
const mongoURI = "mongodb+srv://venturelooptechnologies:W4mQ2tLEhZ84B0pL@ventureloop.m006b.mongodb.net/?retryWrites=true&w=majority&appName=ventureloop";

const connectToMongo = async () => {
    try {
        await mongoose.connect(mongoURI, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
        });
        console.log("Connected to MongoDB Successfully");
    } catch (error) {
        console.error("Error connecting to MongoDB:", error);
    }
};

module.exports = connectToMongo;
