const mongoose = require('mongoose');
const { Schema } = mongoose;

const StartupSchema = new Schema( {
    // Fields from the original StartupSchema
    firstName: {
        type: String,
        
        trim: true,
    },
    lastName: {
        type: String,
       
        trim: true,
    },
    email: {
        type: String,
       
        unique: true,
        match: [/^\S+@\S+\.\S+$/, 'Please enter a valid email address'],
    },
    password: {
        type: String,
      
        minlength: [6, 'Password must be at least 6 characters long'],
    },
    number: {
        type: String,
      
        match: [/^\d{10}$/, 'Please enter a valid 10-digit phone number'],
    },
    founderLinkedIn: {
        type: String,
       
    },
    companyName: {
        type: String,
      
        trim: true,
    },
    companyWebsite: {
        type: String,
       
        trim: true,
    },
    companyLinkedIn: {
        type: String,
        
    },
    sizeOfTeam: {
        type: String,
       
        min: [1, 'Team size must be at least 1'],
    },
    revenue: {
        type: String,
       
        min: [0, 'Revenue cannot be negative'],
    },

    // Fields from the Startup2Schema
    describeProduct: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    describePreviousFundingRound: {
        type: String,
      
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    describeFraction: {
        type: String,
        
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    whyCommunityRound: {
        type: String,
   
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    whyVentureLoop: {
        type: String,
     
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    existingCommitments: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    interestedInPrivateRound: {
        type: String,
        
    },
    startupName: {
        type: String,
        
    },
    foundersdetails: {
        type: String,
        
    },
    industry: {
        type: String,
        
    },
    location: {
        type: String,
        
    },
    stage: {
        type: String,
        
    },
    mvp: {
        type: String,
        
    },
    isServiceIntheMarket: {
        type: String,
        
    },
    traction: {
        type: String,
        
    },
    whichProblemDoesItSolve: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    targetAudience: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    uvp: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    businessModel: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    businessModel: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    raisedBefore: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    howMuchAreYouSeeking: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    howItWillBeUsed: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    currentRevenue: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    projectedtRevenueNextYear: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    totalAddresableMarket: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    mainCompetitors: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    howAreYouDifferent: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    whichTrendsAreYouLeveraging: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    currentTeamSize: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    teammateExpertise: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    membersPlanningToAdd: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    resourcesYouCurrentlyHave: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    shortTermgoals: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    longTermgoals: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    biggestChallengesRightNow: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    supportYouAreLookingFromInvestor: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    doYouHavePitchdeckReady: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    preffereCommunicationMethod: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    HowDoYouWantoAlignWithInvestor: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    customerAcquisitionCost: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    cutomerLifetimeValue: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    currentBurnRate: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    keyPerformanceIndicators: {
        type: String,
       
        maxlength: [1000, 'Maximum length is 1000 characters'],
        trim: true,
    },
    pdf: {
        type: Buffer, // For storing file as binary data
    },
},
{
    timestamps: true,
});

module.exports = mongoose.model('Startup', StartupSchema);